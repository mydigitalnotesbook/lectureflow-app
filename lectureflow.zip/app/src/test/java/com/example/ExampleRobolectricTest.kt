package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.AspectRatio
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun readStringFromContext() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("My Digital Notes Book", appName)
  }

  @Test
  fun testAspectRatioCalculations() {
    val (w169, h169) = AspectRatio.RATIO_16_9.calculateResolution(1080)
    assertEquals(1920, w169)
    assertEquals(1080, h169)

    val (w916, h916) = AspectRatio.RATIO_9_16.calculateResolution(1080)
    assertEquals(1080, w916)
    assertEquals(1920, h916)
  }
}
