package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.data.DeckRepository
import com.example.data.LectureRepository
import com.example.model.AspectRatio
import com.example.model.Deck
import com.example.model.FaceCamBubble
import com.example.model.LectureVideo
import com.example.model.OverlayImage
import com.example.model.OverlayText
import com.example.model.Slide
import com.example.model.SlideSourceType
import com.example.model.Stroke
import com.example.model.ToolType
import com.example.pdf.PdfSlideImporter
import com.example.recorder.RecorderController
import com.example.recorder.RecorderEngine
import com.example.recorder.RecorderState
import com.example.renderer.StageRenderer
import com.example.settings.RecorderConfig
import com.example.settings.RecorderPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

sealed interface Screen {
    data object Home : Screen
    data class SlideList(val deckId: String) : Screen
    data class Stage(val deckId: String, val initialSlideIndex: Int = 0) : Screen
    data object Lectures : Screen
    data object Settings : Screen
    data object About : Screen
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val context: Context get() = getApplication()

    val deckRepository = DeckRepository(context, viewModelScope)
    val lectureRepository = LectureRepository(context, viewModelScope)
    val recorderPreferences = RecorderPreferences(context)
    val recorderController = RecorderController(context, viewModelScope)

    val decks: StateFlow<List<Deck>> = deckRepository.decks
    val lectures: StateFlow<List<LectureVideo>> = lectureRepository.lectures
    val recorderConfig: StateFlow<RecorderConfig> = recorderPreferences.configFlow.stateIn(
        viewModelScope,
        SharingStarted.Eagerly,
        RecorderConfig()
    )
    val recorderState: StateFlow<RecorderState> = recorderController.state

    private val _currentScreen = MutableStateFlow<Screen>(Screen.Home)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val screenStack = mutableListOf<Screen>(Screen.Home)

    // Stage Interaction State
    private val _activeDeck = MutableStateFlow<Deck?>(null)
    val activeDeck: StateFlow<Deck?> = _activeDeck.asStateFlow()

    private val _currentSlideIndex = MutableStateFlow(0)
    val currentSlideIndex: StateFlow<Int> = _currentSlideIndex.asStateFlow()

    private val _activeTool = MutableStateFlow(ToolType.PEN)
    val activeTool: StateFlow<ToolType> = _activeTool.asStateFlow()

    private val _selectedColorArgb = MutableStateFlow(android.graphics.Color.parseColor("#283593"))
    val selectedColorArgb: StateFlow<Int> = _selectedColorArgb.asStateFlow()

    private val _strokeWidthFraction = MutableStateFlow(0.008f)
    val strokeWidthFraction: StateFlow<Float> = _strokeWidthFraction.asStateFlow()

    // Active strokes for the current slide with Undo / Redo support
    private val _currentStrokes = MutableStateFlow<List<Stroke>>(emptyList())
    val currentStrokes: StateFlow<List<Stroke>> = _currentStrokes.asStateFlow()

    // Overlay Images & Texts on the current slide
    private val _currentOverlayImages = MutableStateFlow<List<OverlayImage>>(emptyList())
    val currentOverlayImages: StateFlow<List<OverlayImage>> = _currentOverlayImages.asStateFlow()

    private val _currentOverlayTexts = MutableStateFlow<List<OverlayText>>(emptyList())
    val currentOverlayTexts: StateFlow<List<OverlayText>> = _currentOverlayTexts.asStateFlow()

    // Selected element for moving / resizing / deleting
    private val _selectedElementId = MutableStateFlow<String?>(null)
    val selectedElementId: StateFlow<String?> = _selectedElementId.asStateFlow()

    private val undoStack = mutableListOf<List<Stroke>>()
    private val redoStack = mutableListOf<List<Stroke>>()

    // Face-Cam Bubble State
    private val _faceCamBubble = MutableStateFlow(FaceCamBubble(isEnabled = false))
    val faceCamBubble: StateFlow<FaceCamBubble> = _faceCamBubble.asStateFlow()

    // Toolbar visibility toggle
    private val _isToolbarVisible = MutableStateFlow(true)
    val isToolbarVisible: StateFlow<Boolean> = _isToolbarVisible.asStateFlow()

    // Web Page Mode: Browse vs Draw
    private val _isWebBrowseMode = MutableStateFlow(false)
    val isWebBrowseMode: StateFlow<Boolean> = _isWebBrowseMode.asStateFlow()

    // PDF Import Progress State
    data class PdfImportStatus(val isImporting: Boolean, val current: Int, val total: Int)
    private val _pdfImportStatus = MutableStateFlow(PdfImportStatus(false, 0, 0))
    val pdfImportStatus: StateFlow<PdfImportStatus> = _pdfImportStatus.asStateFlow()

    // UI Events (Toasts, dialogs, notices)
    private val _uiEvents = MutableSharedFlow<String>()
    val uiEvents: SharedFlow<String> = _uiEvents.asSharedFlow()

    init {
        viewModelScope.launch {
            recorderController.events.collect { event ->
                when (event) {
                    is RecorderController.RecorderEvent.Saved -> {
                        lectureRepository.refresh()
                        _uiEvents.emit(context.getString(R.string.toast_recording_saved))
                    }
                    is RecorderController.RecorderEvent.Error -> {
                        _uiEvents.emit(event.message)
                    }
                    is RecorderController.RecorderEvent.LowStorage -> {
                        _uiEvents.emit(event.message)
                    }
                    is RecorderController.RecorderEvent.FallbackNotice -> {
                        _uiEvents.emit(event.message)
                    }
                }
            }
        }
    }

    fun navigateTo(screen: Screen) {
        if (_currentScreen.value != screen) {
            screenStack.add(screen)
            _currentScreen.value = screen

            if (screen is Screen.Stage) {
                loadDeckForStage(screen.deckId, screen.initialSlideIndex)
            } else if (screen is Screen.SlideList) {
                _activeDeck.value = deckRepository.getDeck(screen.deckId)
            }
        }
    }

    fun navigateBack(): Boolean {
        if (screenStack.size > 1) {
            screenStack.removeAt(screenStack.size - 1)
            val prev = screenStack.last()
            _currentScreen.value = prev

            if (prev is Screen.SlideList) {
                _activeDeck.value = deckRepository.getDeck(prev.deckId)
            }
            return true
        }
        return false
    }

    fun createNewDeck(title: String, ratio: AspectRatio, sourceType: SlideSourceType, initialWebUrl: String? = null) {
        viewModelScope.launch {
            val initialSlide = Slide(
                id = UUID.randomUUID().toString(),
                sourceType = sourceType,
                webUrl = initialWebUrl,
                strokes = emptyList()
            )
            val deck = deckRepository.createDeck(title, ratio, listOf(initialSlide))
            _activeDeck.value = deck
            navigateTo(Screen.SlideList(deck.id))
        }
    }

    fun importPdfToDeck(title: String, ratio: AspectRatio, uri: Uri, targetDeckId: String? = null) {
        viewModelScope.launch {
            _pdfImportStatus.value = PdfImportStatus(true, 0, 1)
            val result = PdfSlideImporter.importPdfWithResult(context, uri, ratio) { current, total ->
                _pdfImportStatus.value = PdfImportStatus(true, current, total)
            }
            _pdfImportStatus.value = PdfImportStatus(false, 0, 0)

            if (result.slides.isNotEmpty()) {
                if (targetDeckId != null) {
                    val deck = deckRepository.getDeck(targetDeckId)
                    if (deck != null) {
                        val updated = deck.copy(slides = deck.slides + result.slides)
                        deckRepository.updateDeck(updated)
                        _activeDeck.value = updated
                        _uiEvents.emit("Added ${result.slides.size} PDF pages to deck!")
                        return@launch
                    }
                }

                val finalTitle = if (title.isBlank() || title == "Imported PDF Lesson") result.title else title
                val deck = deckRepository.createDeck(finalTitle, ratio, result.slides)
                _activeDeck.value = deck
                navigateTo(Screen.SlideList(deck.id))
                _uiEvents.emit("Imported ${result.slides.size} pages from PDF!")
            } else {
                _uiEvents.emit(result.errorMessage ?: "Could not open or render PDF file.")
            }
        }
    }

    fun addImagesToDeck(deckId: String, imageUris: List<Uri>) {
        viewModelScope.launch(Dispatchers.IO) {
            val deck = deckRepository.getDeck(deckId) ?: return@launch
            val slidesDir = File(context.filesDir, "slides").apply { mkdirs() }
            val newSlides = mutableListOf<Slide>()

            for (uri in imageUris) {
                val slideFile = File(slidesDir, "img_slide_${UUID.randomUUID()}.jpg")
                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(slideFile).use { output ->
                        input.copyTo(output)
                    }
                }
                newSlides.add(
                    Slide(
                        id = UUID.randomUUID().toString(),
                        sourceType = SlideSourceType.IMAGE,
                        backgroundPath = slideFile.absolutePath,
                        strokes = emptyList()
                    )
                )
            }

            val updatedDeck = deck.copy(slides = deck.slides + newSlides)
            deckRepository.updateDeck(updatedDeck)
            _activeDeck.value = updatedDeck
        }
    }

    fun addBlankSlide(deckId: String, isDark: Boolean) {
        viewModelScope.launch {
            val deck = deckRepository.getDeck(deckId) ?: return@launch
            val newSlide = Slide(
                id = UUID.randomUUID().toString(),
                sourceType = if (isDark) SlideSourceType.BLANK_DARK else SlideSourceType.BLANK_WHITE,
                strokes = emptyList()
            )
            val updated = deck.copy(slides = deck.slides + newSlide)
            deckRepository.updateDeck(updated)
            _activeDeck.value = updated
        }
    }

    fun addWebSlide(deckId: String, url: String) {
        viewModelScope.launch {
            val deck = deckRepository.getDeck(deckId) ?: return@launch
            val newSlide = Slide(
                id = UUID.randomUUID().toString(),
                sourceType = SlideSourceType.WEB_PAGE,
                webUrl = url,
                strokes = emptyList()
            )
            val updated = deck.copy(slides = deck.slides + newSlide)
            deckRepository.updateDeck(updated)
            _activeDeck.value = updated
        }
    }

    fun deleteSlide(deckId: String, slideId: String) {
        viewModelScope.launch {
            val deck = deckRepository.getDeck(deckId) ?: return@launch
            if (deck.slides.size <= 1) {
                _uiEvents.emit("Cannot delete the only slide in the deck.")
                return@launch
            }
            val updatedSlides = deck.slides.filter { it.id != slideId }
            val updatedDeck = deck.copy(slides = updatedSlides)
            deckRepository.updateDeck(updatedDeck)
            _activeDeck.value = updatedDeck
        }
    }

    fun reorderSlides(deckId: String, newSlides: List<Slide>) {
        viewModelScope.launch {
            val deck = deckRepository.getDeck(deckId) ?: return@launch
            val updatedDeck = deck.copy(slides = newSlides)
            deckRepository.updateDeck(updatedDeck)
            _activeDeck.value = updatedDeck
        }
    }

    fun deleteDeck(deckId: String) {
        viewModelScope.launch {
            deckRepository.deleteDeck(deckId)
            navigateBack()
        }
    }

    // Stage controls
    private fun loadDeckForStage(deckId: String, initialIndex: Int) {
        val deck = deckRepository.getDeck(deckId) ?: return
        _activeDeck.value = deck
        val validIndex = initialIndex.coerceIn(0, (deck.slides.size - 1).coerceAtLeast(0))
        _currentSlideIndex.value = validIndex
        loadSlideElements(deck, validIndex)
    }

    private fun loadSlideElements(deck: Deck, index: Int) {
        if (index in deck.slides.indices) {
            val slide = deck.slides[index]
            _currentStrokes.value = slide.strokes
            _currentOverlayImages.value = slide.overlayImages
            _currentOverlayTexts.value = slide.overlayTexts
            _selectedElementId.value = null
            undoStack.clear()
            redoStack.clear()
        }
    }

    fun switchSlide(newIndex: Int) {
        val deck = _activeDeck.value ?: return
        if (newIndex in deck.slides.indices && newIndex != _currentSlideIndex.value) {
            saveCurrentSlideElements()
            _currentSlideIndex.value = newIndex
            loadSlideElements(deck, newIndex)
        }
    }

    fun addStroke(stroke: Stroke) {
        undoStack.add(_currentStrokes.value)
        redoStack.clear()
        val updated = _currentStrokes.value + stroke
        _currentStrokes.value = updated
    }

    fun undo() {
        if (undoStack.isNotEmpty()) {
            redoStack.add(_currentStrokes.value)
            val previous = undoStack.removeAt(undoStack.size - 1)
            _currentStrokes.value = previous
            saveCurrentSlideElements()
        }
    }

    fun redo() {
        if (redoStack.isNotEmpty()) {
            undoStack.add(_currentStrokes.value)
            val next = redoStack.removeAt(redoStack.size - 1)
            _currentStrokes.value = next
            saveCurrentSlideElements()
        }
    }

    fun clearPage() {
        if (_currentStrokes.value.isNotEmpty()) {
            undoStack.add(_currentStrokes.value)
            redoStack.clear()
            _currentStrokes.value = emptyList()
            saveCurrentSlideElements()
        }
    }

    // Overlay Images (Stickers, Cutouts, Photos on slide)
    fun addOverlayImage(uri: Uri) {
        val deck = _activeDeck.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val dir = File(context.filesDir, "overlays").apply { mkdirs() }
            val imageFile = File(dir, "overlay_${UUID.randomUUID()}.jpg")
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(imageFile).use { out ->
                    input.copyTo(out)
                }
            }
            val overlay = OverlayImage(
                id = UUID.randomUUID().toString(),
                imagePath = imageFile.absolutePath,
                normX = 0.5f,
                normY = 0.5f,
                normWidth = 0.35f,
                normHeight = 0.35f
            )
            val updated = _currentOverlayImages.value + overlay
            _currentOverlayImages.value = updated
            _selectedElementId.value = overlay.id
            _activeTool.value = ToolType.SELECT
            saveCurrentSlideElements()
        }
    }

    fun updateOverlayImage(overlay: OverlayImage) {
        val list = _currentOverlayImages.value.map {
            if (it.id == overlay.id) overlay else it
        }
        _currentOverlayImages.value = list
        saveCurrentSlideElements()
    }

    fun deleteOverlayImage(id: String) {
        val list = _currentOverlayImages.value.filter { it.id != id }
        _currentOverlayImages.value = list
        if (_selectedElementId.value == id) _selectedElementId.value = null
        saveCurrentSlideElements()
    }

    fun clearAllImages() {
        _currentOverlayImages.value = emptyList()
        saveCurrentSlideElements()
    }

    // Overlay Texts (Text boxes on slide)
    fun addOverlayText(text: String, colorArgb: Int = _selectedColorArgb.value, fontSizeSp: Float = 22f) {
        val clean = text.trim()
        if (clean.isBlank()) return
        val overlay = OverlayText(
            id = UUID.randomUUID().toString(),
            text = clean,
            normX = 0.5f,
            normY = 0.45f,
            fontSizeSp = fontSizeSp,
            colorArgb = colorArgb,
            isBold = true,
            hasBackground = true
        )
        val updated = _currentOverlayTexts.value + overlay
        _currentOverlayTexts.value = updated
        _selectedElementId.value = overlay.id
        _activeTool.value = ToolType.SELECT
        saveCurrentSlideElements()
    }

    fun updateOverlayText(overlay: OverlayText) {
        val list = _currentOverlayTexts.value.map {
            if (it.id == overlay.id) overlay else it
        }
        _currentOverlayTexts.value = list
        saveCurrentSlideElements()
    }

    fun deleteOverlayText(id: String) {
        val list = _currentOverlayTexts.value.filter { it.id != id }
        _currentOverlayTexts.value = list
        if (_selectedElementId.value == id) _selectedElementId.value = null
        saveCurrentSlideElements()
    }

    fun clearAllTexts() {
        _currentOverlayTexts.value = emptyList()
        if (_selectedElementId.value != null) {
            _selectedElementId.value = null
        }
        saveCurrentSlideElements()
        viewModelScope.launch {
            _uiEvents.emit("All written text boxes removed.")
        }
    }

    fun clearAllSlideAnnotations() {
        undoStack.add(_currentStrokes.value)
        redoStack.clear()
        _currentStrokes.value = emptyList()
        _currentOverlayTexts.value = emptyList()
        _currentOverlayImages.value = emptyList()
        _selectedElementId.value = null
        saveCurrentSlideElements()
    }

    fun selectElement(id: String?) {
        _selectedElementId.value = id
        if (id != null) {
            _activeTool.value = ToolType.SELECT
        }
    }

    fun saveCurrentSlideElements() {
        val deck = _activeDeck.value ?: return
        val index = _currentSlideIndex.value
        if (index in deck.slides.indices) {
            val slide = deck.slides[index]
            viewModelScope.launch {
                deckRepository.saveSlideElements(
                    deckId = deck.id,
                    slideId = slide.id,
                    strokes = _currentStrokes.value,
                    images = _currentOverlayImages.value,
                    texts = _currentOverlayTexts.value
                )
                _activeDeck.value = deckRepository.getDeck(deck.id)
            }
        }
    }

    fun setActiveTool(tool: ToolType) {
        _activeTool.value = tool
        if (tool != ToolType.SELECT) {
            _selectedElementId.value = null
        }
    }

    fun setSelectedColorArgb(argb: Int) {
        _selectedColorArgb.value = argb
    }

    fun setStrokeWidthFraction(fraction: Float) {
        _strokeWidthFraction.value = fraction
    }

    fun toggleFaceCam(enabled: Boolean? = null) {
        val current = _faceCamBubble.value
        val newState = enabled ?: !current.isEnabled
        _faceCamBubble.value = current.copy(isEnabled = newState)
    }

    fun updateFaceCamPosition(normX: Float, normY: Float) {
        val current = _faceCamBubble.value
        _faceCamBubble.value = current.copy(
            normCenterX = normX.coerceIn(0.1f, 0.9f),
            normCenterY = normY.coerceIn(0.1f, 0.9f)
        )
    }

    fun toggleToolbarVisibility() {
        _isToolbarVisible.value = !_isToolbarVisible.value
    }

    fun toggleWebBrowseMode() {
        _isWebBrowseMode.value = !_isWebBrowseMode.value
    }

    fun takeScreenshot(
        stageWidth: Int,
        stageHeight: Int,
        backgroundBitmap: Bitmap? = null,
        webViewBitmap: Bitmap? = null,
        faceCamBitmap: Bitmap? = null
    ) {
        val deck = _activeDeck.value ?: return
        val index = _currentSlideIndex.value
        val slide = deck.slides.getOrNull(index) ?: return

        viewModelScope.launch(Dispatchers.IO) {
            try {
                val bitmap = Bitmap.createBitmap(stageWidth, stageHeight, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bitmap)

                StageRenderer.render(
                    canvas = canvas,
                    w = stageWidth,
                    h = stageHeight,
                    slide = slide.copy(
                        strokes = _currentStrokes.value,
                        overlayImages = _currentOverlayImages.value,
                        overlayTexts = _currentOverlayTexts.value
                    ),
                    strokes = _currentStrokes.value,
                    backgroundBitmap = backgroundBitmap,
                    webViewBitmap = webViewBitmap,
                    faceCamBitmap = faceCamBitmap,
                    faceCamBubble = _faceCamBubble.value
                )

                val fileName = "Snapshot_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.jpg"
                val values = android.content.ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                        put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/My Digital Notes Book")
                    }
                }

                val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
                    }
                    _uiEvents.emit(context.getString(R.string.toast_screenshot_saved))
                }
                bitmap.recycle()
            } catch (e: Exception) {
                _uiEvents.emit("Failed to save snapshot: ${e.localizedMessage}")
            }
        }
    }

    // Recorder Triggers
    fun startRecording(onRenderFrame: (canvas: Canvas, width: Int, height: Int) -> Unit) {
        val deck = _activeDeck.value ?: return
        recorderController.startCountdownAndRecord(
            config = recorderConfig.value,
            ratio = deck.ratio,
            onRenderFrame = onRenderFrame
        )
    }

    fun pauseRecording() {
        recorderController.pauseRecording()
    }

    fun resumeRecording() {
        recorderController.resumeRecording()
    }

    fun stopRecording(lectureTitle: String? = null) {
        saveCurrentSlideElements()
        val deck = _activeDeck.value
        val defaultTitle = deck?.title?.let { "Lecture - $it" }
        recorderController.stopRecording(lectureTitle ?: defaultTitle)
    }

    fun discardRecording() {
        recorderController.discardRecording()
    }
}
