package com.example.camera

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.util.Log
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.util.concurrent.Executors

class FaceCamManager(private val context: Context) {
    private val TAG = "FaceCamManager"
    private val analysisExecutor = Executors.newSingleThreadExecutor()

    @Volatile
    var latestFrameBitmap: Bitmap? = null
        private set

    @Volatile
    var isRunning = false
        private set

    private var cameraProvider: ProcessCameraProvider? = null

    fun start(lifecycleOwner: LifecycleOwner, onFrameAvailable: ((Bitmap) -> Unit)? = null) {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            try {
                val provider = cameraProviderFuture.get()
                cameraProvider = provider

                val imageAnalysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()

                imageAnalysis.setAnalyzer(analysisExecutor) { imageProxy ->
                    processImageProxy(imageProxy, onFrameAvailable)
                }

                val cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA

                provider.unbindAll()
                provider.bindToLifecycle(
                    lifecycleOwner,
                    cameraSelector,
                    imageAnalysis
                )

                isRunning = true
                Log.d(TAG, "Face-cam camera started successfully")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to bind front camera", e)
                isRunning = false
            }
        }, ContextCompat.getMainExecutor(context))
    }

    private fun processImageProxy(imageProxy: ImageProxy, onFrameAvailable: ((Bitmap) -> Unit)?) {
        try {
            // CameraX provides toBitmap() for converting imageProxy
            val rawBitmap = imageProxy.toBitmap()
            val rotationDegrees = imageProxy.imageInfo.rotationDegrees

            // Front camera usually needs mirroring and rotation
            val matrix = Matrix().apply {
                postRotate(rotationDegrees.toFloat())
                postScale(-1f, 1f) // Mirror horizontally for natural front-cam selfie orientation
            }

            val rotated = Bitmap.createBitmap(
                rawBitmap,
                0,
                0,
                rawBitmap.width,
                rawBitmap.height,
                matrix,
                true
            )

            val old = latestFrameBitmap
            latestFrameBitmap = rotated
            if (old != null && old != rawBitmap) {
                old.recycle()
            }
            if (rawBitmap != rotated) {
                rawBitmap.recycle()
            }

            onFrameAvailable?.invoke(rotated)
        } catch (e: Exception) {
            Log.w(TAG, "Error processing camera frame", e)
        } finally {
            imageProxy.close()
        }
    }

    fun stop() {
        isRunning = false
        try {
            cameraProvider?.unbindAll()
        } catch (e: Exception) {
            Log.w(TAG, "Error unbinding camera", e)
        }
        latestFrameBitmap?.recycle()
        latestFrameBitmap = null
    }
}
