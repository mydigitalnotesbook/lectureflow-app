package com.example.settings

import android.content.Context
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.media.MediaRecorder
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.AspectRatio
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "recorder_settings")

enum class AudioSourceOption(val sourceValue: Int, val label: String) {
    MIC(MediaRecorder.AudioSource.MIC, "Microphone (MIC)"),
    CAMCORDER(MediaRecorder.AudioSource.CAMCORDER, "Camcorder Audio Source")
}

enum class AudioBitrateOption(val kbps: Int, val bps: Int) {
    KBPS_64(64, 64_000),
    KBPS_128(128, 128_000),
    KBPS_192(192, 192_000)
}

enum class VideoCodecOption(val mimeType: String, val label: String) {
    H264(MediaFormat.MIMETYPE_VIDEO_AVC, "H.264 (AVC)"),
    HEVC(MediaFormat.MIMETYPE_VIDEO_HEVC, "H.265 (HEVC)")
}

enum class QualityOption(val shortSide: Int, val label: String) {
    P720(720, "720p HD"),
    P1080(1080, "1080p Full HD")
}

enum class FpsOption(val fps: Int) {
    FPS_24(24),
    FPS_30(30),
    FPS_60(60)
}

enum class VideoBitrateOption(val mbps: Int, val bps: Int) {
    MBPS_2(2, 2_000_000),
    MBPS_4(4, 4_000_000),
    MBPS_6(6, 6_000_000),
    MBPS_8(8, 8_000_000)
}

data class RecorderConfig(
    val audioSource: AudioSourceOption = AudioSourceOption.MIC,
    val audioBitrate: AudioBitrateOption = AudioBitrateOption.KBPS_128,
    val videoCodec: VideoCodecOption = VideoCodecOption.H264,
    val quality: QualityOption = QualityOption.P1080,
    val fps: FpsOption = FpsOption.FPS_30,
    val videoBitrate: VideoBitrateOption = VideoBitrateOption.MBPS_4,
    val defaultRatio: AspectRatio = AspectRatio.RATIO_16_9
)

class RecorderPreferences(private val context: Context) {

    private object Keys {
        val AUDIO_SOURCE = stringPreferencesKey("audio_source")
        val AUDIO_BITRATE = intPreferencesKey("audio_bitrate")
        val VIDEO_CODEC = stringPreferencesKey("video_codec")
        val QUALITY = intPreferencesKey("quality")
        val FPS = intPreferencesKey("fps")
        val VIDEO_BITRATE = intPreferencesKey("video_bitrate")
        val DEFAULT_RATIO = stringPreferencesKey("default_ratio")
    }

    val configFlow: Flow<RecorderConfig> = context.dataStore.data.map { prefs ->
        val audioSource = prefs[Keys.AUDIO_SOURCE]?.let { name ->
            runCatching { AudioSourceOption.valueOf(name) }.getOrNull()
        } ?: AudioSourceOption.MIC

        val audioBitrate = prefs[Keys.AUDIO_BITRATE]?.let { kbps ->
            AudioBitrateOption.values().firstOrNull { it.kbps == kbps }
        } ?: AudioBitrateOption.KBPS_128

        val videoCodec = prefs[Keys.VIDEO_CODEC]?.let { name ->
            runCatching { VideoCodecOption.valueOf(name) }.getOrNull()
        } ?: VideoCodecOption.H264

        val quality = prefs[Keys.QUALITY]?.let { shortSide ->
            QualityOption.values().firstOrNull { it.shortSide == shortSide }
        } ?: QualityOption.P1080

        val fps = prefs[Keys.FPS]?.let { f ->
            FpsOption.values().firstOrNull { it.fps == f }
        } ?: FpsOption.FPS_30

        val videoBitrate = prefs[Keys.VIDEO_BITRATE]?.let { mbps ->
            VideoBitrateOption.values().firstOrNull { it.mbps == mbps }
        } ?: VideoBitrateOption.MBPS_4

        val defaultRatio = prefs[Keys.DEFAULT_RATIO]?.let { r ->
            runCatching { AspectRatio.valueOf(r) }.getOrNull()
        } ?: AspectRatio.RATIO_16_9

        RecorderConfig(
            audioSource = audioSource,
            audioBitrate = audioBitrate,
            videoCodec = videoCodec,
            quality = quality,
            fps = fps,
            videoBitrate = videoBitrate,
            defaultRatio = defaultRatio
        )
    }

    suspend fun updateAudioSource(option: AudioSourceOption) {
        context.dataStore.edit { it[Keys.AUDIO_SOURCE] = option.name }
    }

    suspend fun updateAudioBitrate(option: AudioBitrateOption) {
        context.dataStore.edit { it[Keys.AUDIO_BITRATE] = option.kbps }
    }

    suspend fun updateVideoCodec(option: VideoCodecOption) {
        context.dataStore.edit { it[Keys.VIDEO_CODEC] = option.name }
    }

    suspend fun updateQuality(option: QualityOption) {
        context.dataStore.edit { it[Keys.QUALITY] = option.shortSide }
    }

    suspend fun updateFps(option: FpsOption) {
        context.dataStore.edit { it[Keys.FPS] = option.fps }
    }

    suspend fun updateVideoBitrate(option: VideoBitrateOption) {
        context.dataStore.edit { it[Keys.VIDEO_BITRATE] = option.mbps }
    }

    suspend fun updateDefaultRatio(ratio: AspectRatio) {
        context.dataStore.edit { it[Keys.DEFAULT_RATIO] = ratio.name }
    }

    suspend fun resetToDefaults() {
        context.dataStore.edit { prefs ->
            prefs.clear()
        }
    }

    companion object {
        fun testHardwareCapabilities(): HardwareReport {
            val codecList = MediaCodecList(MediaCodecList.REGULAR_CODECS)
            val infos = codecList.codecInfos

            var h264Supported = false
            var hevcSupported = false
            var h264MaxResolution = "Unknown"
            var hevcMaxResolution = "Unsupported"
            var maxFpsH264 = 30
            var maxFpsHevc = 30

            for (info in infos) {
                if (!info.isEncoder) continue
                for (type in info.supportedTypes) {
                    if (type.equals(MediaFormat.MIMETYPE_VIDEO_AVC, ignoreCase = true)) {
                        h264Supported = true
                        runCatching {
                            val caps = info.getCapabilitiesForType(type).videoCapabilities
                            if (caps != null) {
                                h264MaxResolution = "${caps.supportedWidths.upper}x${caps.supportedHeights.upper}"
                                maxFpsH264 = caps.supportedFrameRates.upper.toInt()
                            }
                        }
                    }
                    if (type.equals(MediaFormat.MIMETYPE_VIDEO_HEVC, ignoreCase = true)) {
                        hevcSupported = true
                        runCatching {
                            val caps = info.getCapabilitiesForType(type).videoCapabilities
                            if (caps != null) {
                                hevcMaxResolution = "${caps.supportedWidths.upper}x${caps.supportedHeights.upper}"
                                maxFpsHevc = caps.supportedFrameRates.upper.toInt()
                            }
                        }
                    }
                }
            }

            return HardwareReport(
                h264Supported = h264Supported,
                hevcSupported = hevcSupported,
                h264MaxResolution = h264MaxResolution,
                hevcMaxResolution = hevcMaxResolution,
                maxFpsH264 = maxFpsH264,
                maxFpsHevc = maxFpsHevc
            )
        }
    }
}

data class HardwareReport(
    val h264Supported: Boolean,
    val hevcSupported: Boolean,
    val h264MaxResolution: String,
    val hevcMaxResolution: String,
    val maxFpsH264: Int,
    val maxFpsHevc: Int
)
