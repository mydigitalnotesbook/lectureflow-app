package com.example.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.util.Log
import com.example.model.AspectRatio
import com.example.model.Slide
import com.example.model.SlideSourceType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

object PdfSlideImporter {
    private const val TAG = "PdfSlideImporter"

    data class PdfImportResult(
        val title: String,
        val slides: List<Slide>,
        val errorMessage: String? = null
    )

    suspend fun importPdfWithResult(
        context: Context,
        pdfUri: Uri,
        targetRatio: AspectRatio,
        onProgress: (current: Int, total: Int) -> Unit
    ): PdfImportResult = withContext(Dispatchers.IO) {
        val slides = mutableListOf<Slide>()
        var docTitle = "PDF Document"

        // Extract filename if available
        try {
            context.contentResolver.query(pdfUri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameIndex >= 0 && cursor.moveToFirst()) {
                    val name = cursor.getString(nameIndex)
                    if (!name.isNullOrBlank()) {
                        docTitle = name.removeSuffix(".pdf").removeSuffix(".PDF")
                    }
                }
            }
        } catch (ignored: Exception) {
        }

        // Copy input URI to temporary file
        val tempFile = File(context.cacheDir, "import_temp_${System.currentTimeMillis()}.pdf")
        try {
            context.contentResolver.openInputStream(pdfUri)?.use { input ->
                FileOutputStream(tempFile).use { output ->
                    input.copyTo(output)
                }
            } ?: return@withContext PdfImportResult(docTitle, emptyList(), "Could not open selected file")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to copy input PDF stream", e)
            return@withContext PdfImportResult(docTitle, emptyList(), "Failed to read file: ${e.localizedMessage}")
        }

        var pfd: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null
        try {
            pfd = ParcelFileDescriptor.open(tempFile, ParcelFileDescriptor.MODE_READ_ONLY)
            renderer = PdfRenderer(pfd)
            val pageCount = renderer.pageCount
            val slidesDir = File(context.filesDir, "slides").apply { mkdirs() }

            val (targetW, targetH) = targetRatio.calculateResolution(1080)

            for (i in 0 until pageCount) {
                onProgress(i + 1, pageCount)
                val page = renderer.openPage(i)

                val pageW = page.width
                val pageH = page.height
                val scale = minOf(targetW.toFloat() / pageW, targetH.toFloat() / pageH).coerceAtLeast(0.5f)
                val renderW = (pageW * scale).toInt().coerceAtLeast(1)
                val renderH = (pageH * scale).toInt().coerceAtLeast(1)

                val bitmap = Bitmap.createBitmap(renderW, renderH, Bitmap.Config.ARGB_8888)
                val canvas = android.graphics.Canvas(bitmap)
                canvas.drawColor(Color.WHITE)

                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                page.close()

                val slideFile = File(slidesDir, "pdf_slide_${UUID.randomUUID()}.jpg")
                FileOutputStream(slideFile).use { fos ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 92, fos)
                }
                bitmap.recycle()

                slides.add(
                    Slide(
                        id = UUID.randomUUID().toString(),
                        sourceType = SlideSourceType.PDF_PAGE,
                        backgroundPath = slideFile.absolutePath,
                        strokes = emptyList()
                    )
                )
            }
        } catch (e: SecurityException) {
            Log.e(TAG, "Password protected PDF", e)
            return@withContext PdfImportResult(docTitle, emptyList(), "PDF is password protected or encrypted")
        } catch (e: Exception) {
            Log.e(TAG, "Error rendering PDF pages", e)
            return@withContext PdfImportResult(docTitle, emptyList(), "Error reading PDF: ${e.localizedMessage}")
        } finally {
            renderer?.close()
            pfd?.close()
            tempFile.delete()
        }

        PdfImportResult(docTitle, slides)
    }

    suspend fun importPdf(
        context: Context,
        pdfUri: Uri,
        targetRatio: AspectRatio,
        onProgress: (current: Int, total: Int) -> Unit
    ): List<Slide> {
        return importPdfWithResult(context, pdfUri, targetRatio, onProgress).slides
    }
}
