package com.example.renderer

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import com.example.model.FaceCamBubble
import com.example.model.OverlayImage
import com.example.model.OverlayText
import com.example.model.Slide
import com.example.model.SlideSourceType
import com.example.model.Stroke
import com.example.model.ToolType
import java.io.File
import java.util.concurrent.ConcurrentHashMap

object StageRenderer {

    private val bgPaint = Paint().apply {
        isAntiAlias = true
        style = Paint.Style.FILL
    }

    private val strokePaint = Paint().apply {
        isAntiAlias = true
        isDither = true
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private val bitmapPaint = Paint().apply {
        isAntiAlias = true
        isFilterBitmap = true
    }

    private val textBgPaint = Paint().apply {
        isAntiAlias = true
        style = Paint.Style.FILL
        color = 0xCC1E2230.toInt()
    }

    private val textPaint = Paint().apply {
        isAntiAlias = true
        style = Paint.Style.FILL
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }

    private val bubbleBorderPaint = Paint().apply {
        isAntiAlias = true
        style = Paint.Style.STROKE
        color = Color.WHITE
        strokeWidth = 4f
    }

    private val bubbleShadowPaint = Paint().apply {
        isAntiAlias = true
        style = Paint.Style.STROKE
        color = 0x55000000
        strokeWidth = 6f
    }

    // Cache decoded overlay bitmaps for fast rendering during video encoding
    private val overlayBitmapCache = ConcurrentHashMap<String, Bitmap>()

    fun getOrLoadOverlayBitmap(path: String): Bitmap? {
        val cached = overlayBitmapCache[path]
        if (cached != null && !cached.isRecycled) return cached

        return try {
            val file = File(path)
            if (file.exists()) {
                val decoded = BitmapFactory.decodeFile(file.absolutePath)
                if (decoded != null) {
                    overlayBitmapCache[path] = decoded
                }
                decoded
            } else null
        } catch (e: Exception) {
            null
        }
    }

    fun clearOverlayCache() {
        overlayBitmapCache.values.forEach { runCatching { it.recycle() } }
        overlayBitmapCache.clear()
    }

    /**
     * Unified stroke drawing function used by preview, screenshot, and video encoder.
     * Normalized coordinates (0f..1f) are mapped to actual canvas dimensions (w, h).
     */
    fun drawStrokes(
        canvas: Canvas,
        strokes: List<Stroke>,
        w: Float,
        h: Float,
        slideSourceType: SlideSourceType = SlideSourceType.BLANK_WHITE
    ) {
        val path = Path()
        for (stroke in strokes) {
            val points = stroke.points
            if (points.isEmpty()) continue

            path.reset()
            val firstX = points[0].x * w
            val firstY = points[0].y * h
            path.moveTo(firstX, firstY)

            if (points.size == 1) {
                // Single tap dot
                path.lineTo(firstX + 0.5f, firstY + 0.5f)
            } else {
                for (i in 1 until points.size) {
                    val px = points[i].x * w
                    val py = points[i].y * h
                    val prevX = points[i - 1].x * w
                    val prevY = points[i - 1].y * h
                    val midX = (prevX + px) / 2f
                    val midY = (prevY + py) / 2f
                    path.quadTo(prevX, prevY, midX, midY)
                }
                val last = points.last()
                path.lineTo(last.x * w, last.y * h)
            }

            val strokeWidthPx = (stroke.strokeWidthFraction * w).coerceAtLeast(1.5f)
            strokePaint.strokeWidth = strokeWidthPx

            when (stroke.tool) {
                ToolType.PEN, ToolType.SELECT -> {
                    strokePaint.xfermode = null
                    strokePaint.color = stroke.colorArgb
                    strokePaint.alpha = 255
                    canvas.drawPath(path, strokePaint)
                }
                ToolType.HIGHLIGHTER -> {
                    strokePaint.xfermode = null
                    val c = stroke.colorArgb
                    val semiTransparent = Color.argb(
                        96,
                        Color.red(c),
                        Color.green(c),
                        Color.blue(c)
                    )
                    strokePaint.color = semiTransparent
                    strokePaint.strokeWidth = strokeWidthPx * 2.2f
                    canvas.drawPath(path, strokePaint)
                }
                ToolType.ERASER -> {
                    val eraseColor = when (slideSourceType) {
                        SlideSourceType.BLANK_DARK -> Color.parseColor("#12141C")
                        else -> Color.WHITE
                    }
                    strokePaint.xfermode = null
                    strokePaint.color = eraseColor
                    strokePaint.strokeWidth = strokeWidthPx * 2.5f
                    canvas.drawPath(path, strokePaint)
                }
            }
        }
    }

    /**
     * Master render function that paints background + fitted slide + overlay images + overlay texts + strokes (+ face-cam).
     * Used identically for preview, screenshot, and video encoder surfaces.
     */
    fun render(
        canvas: Canvas,
        w: Int,
        h: Int,
        slide: Slide,
        strokes: List<Stroke> = slide.strokes,
        backgroundBitmap: Bitmap? = null,
        webViewBitmap: Bitmap? = null,
        faceCamBitmap: Bitmap? = null,
        faceCamBubble: FaceCamBubble? = null
    ) {
        val widthF = w.toFloat()
        val heightF = h.toFloat()

        // 1. Paint background color
        val bgColor = when (slide.sourceType) {
            SlideSourceType.BLANK_DARK -> Color.parseColor("#12141C")
            else -> Color.WHITE
        }
        bgPaint.color = bgColor
        canvas.drawRect(0f, 0f, widthF, heightF, bgPaint)

        // 2. Paint background image or PDF page (if available)
        if (backgroundBitmap != null && !backgroundBitmap.isRecycled) {
            val bmpW = backgroundBitmap.width
            val bmpH = backgroundBitmap.height
            val scale = minOf(widthF / bmpW, heightF / bmpH)
            val destW = bmpW * scale
            val destH = bmpH * scale
            val left = (widthF - destW) / 2f
            val top = (heightF - destH) / 2f
            val destRect = RectF(left, top, left + destW, top + destH)
            canvas.drawBitmap(backgroundBitmap, null, destRect, bitmapPaint)
        }

        // 3. Paint web view snapshot (if web slide)
        if (slide.sourceType == SlideSourceType.WEB_PAGE && webViewBitmap != null && !webViewBitmap.isRecycled) {
            val destRect = RectF(0f, 0f, widthF, heightF)
            canvas.drawBitmap(webViewBitmap, null, destRect, bitmapPaint)
        }

        // 4. Paint Overlay Images (Cutouts, illustrations, photos placed on slide)
        for (img in slide.overlayImages) {
            val bmp = getOrLoadOverlayBitmap(img.imagePath)
            if (bmp != null && !bmp.isRecycled) {
                val cx = img.normX * widthF
                val cy = img.normY * heightF
                val imgW = img.normWidth * widthF
                val imgH = img.normHeight * heightF
                val rect = RectF(cx - imgW / 2f, cy - imgH / 2f, cx + imgW / 2f, cy + imgH / 2f)
                canvas.drawBitmap(bmp, null, rect, bitmapPaint)
            }
        }

        // 5. Paint Overlay Texts (Customizable text boxes)
        val baseScale = (widthF / 1080f).coerceAtLeast(0.6f)
        for (item in slide.overlayTexts) {
            val cx = item.normX * widthF
            val cy = item.normY * heightF
            val textSizePx = item.fontSizeSp * baseScale * 1.6f
            textPaint.textSize = textSizePx
            textPaint.color = item.colorArgb
            textPaint.typeface = if (item.isBold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT

            val lines = item.text.split("\n")
            val maxLineW = lines.maxOfOrNull { textPaint.measureText(it) } ?: 0f
            val lineHeight = textSizePx * 1.25f
            val totalTextH = lineHeight * lines.size

            if (item.hasBackground) {
                val padX = 14f * baseScale
                val padY = 8f * baseScale
                val bgRect = RectF(
                    cx - maxLineW / 2f - padX,
                    cy - totalTextH / 2f - padY,
                    cx + maxLineW / 2f + padX,
                    cy + totalTextH / 2f + padY
                )
                // If text color is dark, make background light; if text color is light, make background dark
                val isLightText = Color.red(item.colorArgb) + Color.green(item.colorArgb) + Color.blue(item.colorArgb) > 380
                textBgPaint.color = if (isLightText) Color.parseColor("#D012141C") else Color.parseColor("#E0FFFFFF")
                canvas.drawRoundRect(bgRect, 10f * baseScale, 10f * baseScale, textBgPaint)
            }

            var startY = cy - (totalTextH / 2f) + textSizePx * 0.85f
            for (line in lines) {
                val lineW = textPaint.measureText(line)
                val lineX = cx - (lineW / 2f)
                canvas.drawText(line, lineX, startY, textPaint)
                startY += lineHeight
            }
        }

        // 6. Paint Normalized Drawing Strokes ON TOP of everything
        drawStrokes(canvas, strokes, widthF, heightF, slide.sourceType)

        // 7. Paint Face-Cam round bubble (if enabled)
        if (faceCamBubble != null && faceCamBubble.isEnabled && faceCamBitmap != null && !faceCamBitmap.isRecycled) {
            val cx = faceCamBubble.normCenterX * widthF
            val cy = faceCamBubble.normCenterY * heightF
            val radius = faceCamBubble.normRadius * widthF

            canvas.save()
            val clipPath = Path().apply {
                addCircle(cx, cy, radius, Path.Direction.CW)
            }
            canvas.clipPath(clipPath)

            val bw = faceCamBitmap.width
            val bh = faceCamBitmap.height
            val minSide = minOf(bw, bh)
            val srcRect = Rect(
                (bw - minSide) / 2,
                (bh - minSide) / 2,
                (bw + minSide) / 2,
                (bh + minSide) / 2
            )
            val dstRect = RectF(cx - radius, cy - radius, cx + radius, cy + radius)
            canvas.drawBitmap(faceCamBitmap, srcRect, dstRect, bitmapPaint)
            canvas.restore()

            canvas.drawCircle(cx, cy, radius, bubbleShadowPaint)
            bubbleBorderPaint.color = Color.parseColor("#FF5722") // Coral border
            canvas.drawCircle(cx, cy, radius, bubbleBorderPaint)
        }
    }
}
