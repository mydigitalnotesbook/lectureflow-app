package com.example.data

import android.content.Context
import com.example.model.AspectRatio
import com.example.model.Deck
import com.example.model.OverlayImage
import com.example.model.OverlayText
import com.example.model.PointF
import com.example.model.Slide
import com.example.model.SlideSourceType
import com.example.model.Stroke
import com.example.model.ToolType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

class DeckRepository(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private val storageFile = File(context.filesDir, "decks_store.json")
    private val _decks = MutableStateFlow<List<Deck>>(emptyList())
    val decks: StateFlow<List<Deck>> = _decks.asStateFlow()

    init {
        scope.launch(Dispatchers.IO) {
            loadDecks()
        }
    }

    private suspend fun loadDecks() = withContext(Dispatchers.IO) {
        if (!storageFile.exists()) {
            val initial = createSeedDecks()
            _decks.value = initial
            persistDecks(initial)
            return@withContext
        }

        try {
            val jsonStr = storageFile.readText()
            val jsonArray = JSONArray(jsonStr)
            val list = mutableListOf<Deck>()

            for (i in 0 until jsonArray.length()) {
                val deckObj = jsonArray.getJSONObject(i)
                val id = deckObj.getString("id")
                val title = deckObj.getString("title")
                val ratioStr = deckObj.optString("ratio", AspectRatio.RATIO_16_9.name)
                val ratio = runCatching { AspectRatio.valueOf(ratioStr) }.getOrDefault(AspectRatio.RATIO_16_9)
                val updatedAt = deckObj.optLong("updatedAt", System.currentTimeMillis())

                val slidesArray = deckObj.optJSONArray("slides") ?: JSONArray()
                val slides = mutableListOf<Slide>()

                for (j in 0 until slidesArray.length()) {
                    val slideObj = slidesArray.getJSONObject(j)
                    val sId = slideObj.getString("id")
                    val sTypeStr = slideObj.getString("sourceType")
                    val sType = runCatching { SlideSourceType.valueOf(sTypeStr) }.getOrDefault(SlideSourceType.BLANK_WHITE)
                    val bgPath = slideObj.optString("backgroundPath").takeIf { it.isNotBlank() }
                    val webUrl = slideObj.optString("webUrl").takeIf { it.isNotBlank() }

                    // Parse Overlay Images
                    val imagesArray = slideObj.optJSONArray("overlayImages") ?: JSONArray()
                    val overlayImages = mutableListOf<OverlayImage>()
                    for (m in 0 until imagesArray.length()) {
                        val imgObj = imagesArray.getJSONObject(m)
                        overlayImages.add(
                            OverlayImage(
                                id = imgObj.getString("id"),
                                imagePath = imgObj.getString("imagePath"),
                                normX = imgObj.getDouble("normX").toFloat(),
                                normY = imgObj.getDouble("normY").toFloat(),
                                normWidth = imgObj.optDouble("normWidth", 0.35).toFloat(),
                                normHeight = imgObj.optDouble("normHeight", 0.35).toFloat()
                            )
                        )
                    }

                    // Parse Overlay Texts
                    val textsArray = slideObj.optJSONArray("overlayTexts") ?: JSONArray()
                    val overlayTexts = mutableListOf<OverlayText>()
                    for (t in 0 until textsArray.length()) {
                        val txtObj = textsArray.getJSONObject(t)
                        overlayTexts.add(
                            OverlayText(
                                id = txtObj.getString("id"),
                                text = txtObj.getString("text"),
                                normX = txtObj.getDouble("normX").toFloat(),
                                normY = txtObj.getDouble("normY").toFloat(),
                                fontSizeSp = txtObj.optDouble("fontSizeSp", 22.0).toFloat(),
                                colorArgb = txtObj.optInt("colorArgb", -1),
                                isBold = txtObj.optBoolean("isBold", true),
                                hasBackground = txtObj.optBoolean("hasBackground", true)
                            )
                        )
                    }

                    // Parse Strokes
                    val strokesArray = slideObj.optJSONArray("strokes") ?: JSONArray()
                    val strokes = mutableListOf<Stroke>()

                    for (k in 0 until strokesArray.length()) {
                        val strokeObj = strokesArray.getJSONObject(k)
                        val color = strokeObj.getInt("colorArgb")
                        val widthFrac = strokeObj.getDouble("strokeWidthFraction").toFloat()
                        val toolStr = strokeObj.optString("tool", ToolType.PEN.name)
                        val tool = runCatching { ToolType.valueOf(toolStr) }.getOrDefault(ToolType.PEN)

                        val pointsArray = strokeObj.getJSONArray("points")
                        val points = mutableListOf<PointF>()
                        for (p in 0 until pointsArray.length()) {
                            val ptObj = pointsArray.getJSONObject(p)
                            points.add(PointF(ptObj.getDouble("x").toFloat(), ptObj.getDouble("y").toFloat()))
                        }

                        strokes.add(Stroke(points, color, widthFrac, tool))
                    }

                    slides.add(Slide(sId, sType, bgPath, webUrl, overlayImages, overlayTexts, strokes))
                }

                list.add(Deck(id, title, ratio, slides, updatedAt))
            }

            _decks.value = list
        } catch (e: Exception) {
            val fallback = createSeedDecks()
            _decks.value = fallback
            persistDecks(fallback)
        }
    }

    private fun persistDecks(decksToSave: List<Deck>) {
        try {
            val jsonArray = JSONArray()
            for (deck in decksToSave) {
                val deckObj = JSONObject()
                deckObj.put("id", deck.id)
                deckObj.put("title", deck.title)
                deckObj.put("ratio", deck.ratio.name)
                deckObj.put("updatedAt", deck.updatedAt)

                val slidesArray = JSONArray()
                for (slide in deck.slides) {
                    val slideObj = JSONObject()
                    slideObj.put("id", slide.id)
                    slideObj.put("sourceType", slide.sourceType.name)
                    slideObj.put("backgroundPath", slide.backgroundPath ?: "")
                    slideObj.put("webUrl", slide.webUrl ?: "")

                    // Save Overlay Images
                    val imagesArray = JSONArray()
                    for (img in slide.overlayImages) {
                        val imgObj = JSONObject()
                        imgObj.put("id", img.id)
                        imgObj.put("imagePath", img.imagePath)
                        imgObj.put("normX", img.normX.toDouble())
                        imgObj.put("normY", img.normY.toDouble())
                        imgObj.put("normWidth", img.normWidth.toDouble())
                        imgObj.put("normHeight", img.normHeight.toDouble())
                        imagesArray.put(imgObj)
                    }
                    slideObj.put("overlayImages", imagesArray)

                    // Save Overlay Texts
                    val textsArray = JSONArray()
                    for (txt in slide.overlayTexts) {
                        val txtObj = JSONObject()
                        txtObj.put("id", txt.id)
                        txtObj.put("text", txt.text)
                        txtObj.put("normX", txt.normX.toDouble())
                        txtObj.put("normY", txt.normY.toDouble())
                        txtObj.put("fontSizeSp", txt.fontSizeSp.toDouble())
                        txtObj.put("colorArgb", txt.colorArgb)
                        txtObj.put("isBold", txt.isBold)
                        txtObj.put("hasBackground", txt.hasBackground)
                        textsArray.put(txtObj)
                    }
                    slideObj.put("overlayTexts", textsArray)

                    // Save Strokes
                    val strokesArray = JSONArray()
                    for (stroke in slide.strokes) {
                        val strokeObj = JSONObject()
                        strokeObj.put("colorArgb", stroke.colorArgb)
                        strokeObj.put("strokeWidthFraction", stroke.strokeWidthFraction.toDouble())
                        strokeObj.put("tool", stroke.tool.name)

                        val pointsArray = JSONArray()
                        for (pt in stroke.points) {
                            val ptObj = JSONObject()
                            ptObj.put("x", pt.x.toDouble())
                            ptObj.put("y", pt.y.toDouble())
                            pointsArray.put(ptObj)
                        }
                        strokeObj.put("points", pointsArray)
                        strokesArray.put(strokeObj)
                    }

                    slideObj.put("strokes", strokesArray)
                    slidesArray.put(slideObj)
                }

                deckObj.put("slides", slidesArray)
                jsonArray.put(deckObj)
            }

            storageFile.writeText(jsonArray.toString())
        } catch (ignored: Exception) {
        }
    }

    fun getDeck(deckId: String): Deck? {
        return _decks.value.firstOrNull { it.id == deckId }
    }

    suspend fun createDeck(title: String, ratio: AspectRatio, initialSlides: List<Slide>): Deck = withContext(Dispatchers.IO) {
        val newDeck = Deck(
            id = UUID.randomUUID().toString(),
            title = title,
            ratio = ratio,
            slides = if (initialSlides.isEmpty()) listOf(Slide(UUID.randomUUID().toString(), SlideSourceType.BLANK_WHITE)) else initialSlides,
            updatedAt = System.currentTimeMillis()
        )
        val updated = listOf(newDeck) + _decks.value
        _decks.value = updated
        persistDecks(updated)
        newDeck
    }

    suspend fun updateDeck(updatedDeck: Deck) = withContext(Dispatchers.IO) {
        val updatedList = _decks.value.map {
            if (it.id == updatedDeck.id) updatedDeck.copy(updatedAt = System.currentTimeMillis()) else it
        }
        _decks.value = updatedList
        persistDecks(updatedList)
    }

    suspend fun deleteDeck(deckId: String) = withContext(Dispatchers.IO) {
        val updatedList = _decks.value.filter { it.id != deckId }
        _decks.value = updatedList
        persistDecks(updatedList)
    }

    suspend fun saveSlideElements(
        deckId: String,
        slideId: String,
        strokes: List<Stroke>,
        images: List<OverlayImage>,
        texts: List<OverlayText>
    ) = withContext(Dispatchers.IO) {
        val currentDecks = _decks.value
        val deck = currentDecks.firstOrNull { it.id == deckId } ?: return@withContext
        val updatedSlides = deck.slides.map {
            if (it.id == slideId) it.copy(strokes = strokes, overlayImages = images, overlayTexts = texts) else it
        }
        val updatedDeck = deck.copy(slides = updatedSlides, updatedAt = System.currentTimeMillis())
        updateDeck(updatedDeck)
    }

    private fun createSeedDecks(): List<Deck> {
        val deck1 = Deck(
            id = "seed_deck_math",
            title = "Introduction to Functions & Graphs",
            ratio = AspectRatio.RATIO_16_9,
            slides = listOf(
                Slide(
                    id = "seed_slide_1",
                    sourceType = SlideSourceType.BLANK_WHITE,
                    overlayTexts = listOf(
                        OverlayText(
                            id = "seed_txt_1",
                            text = "y = f(x) = x² + 2",
                            normX = 0.5f,
                            normY = 0.16f,
                            fontSizeSp = 24f,
                            colorArgb = android.graphics.Color.parseColor("#283593"),
                            isBold = true,
                            hasBackground = true
                        )
                    ),
                    strokes = listOf(
                        Stroke(
                            points = listOf(
                                PointF(0.2f, 0.4f), PointF(0.5f, 0.65f), PointF(0.8f, 0.4f)
                            ),
                            colorArgb = android.graphics.Color.parseColor("#FF5722"),
                            strokeWidthFraction = 0.008f,
                            tool = ToolType.PEN
                        )
                    )
                ),
                Slide(
                    id = "seed_slide_2",
                    sourceType = SlideSourceType.BLANK_DARK,
                    strokes = emptyList()
                )
            ),
            updatedAt = System.currentTimeMillis() - 86400000L
        )

        val deck2 = Deck(
            id = "seed_deck_physics",
            title = "Mobile Physics Short: Newton's Laws",
            ratio = AspectRatio.RATIO_9_16,
            slides = listOf(
                Slide(
                    id = "seed_slide_p1",
                    sourceType = SlideSourceType.BLANK_WHITE,
                    overlayTexts = listOf(
                        OverlayText(
                            id = "seed_txt_p1",
                            text = "F = m · a",
                            normX = 0.5f,
                            normY = 0.2f,
                            fontSizeSp = 28f,
                            colorArgb = android.graphics.Color.parseColor("#D50000"),
                            isBold = true,
                            hasBackground = true
                        )
                    ),
                    strokes = emptyList()
                )
            ),
            updatedAt = System.currentTimeMillis() - 172800000L
        )

        return listOf(deck1, deck2)
    }
}
