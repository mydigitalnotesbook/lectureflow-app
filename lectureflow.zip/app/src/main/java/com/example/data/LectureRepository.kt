package com.example.data

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import com.example.model.AspectRatio
import com.example.model.LectureVideo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class LectureRepository(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private val TAG = "LectureRepository"
    private val _lectures = MutableStateFlow<List<LectureVideo>>(emptyList())
    val lectures: StateFlow<List<LectureVideo>> = _lectures.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        scope.launch(Dispatchers.IO) {
            val list = querySavedLectures()
            _lectures.value = list
        }
    }

    private suspend fun querySavedLectures(): List<LectureVideo> = withContext(Dispatchers.IO) {
        val results = mutableListOf<LectureVideo>()
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT
        )

        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }

        try {
            val selection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                "${MediaStore.Video.Media.RELATIVE_PATH} LIKE ?"
            } else {
                "${MediaStore.Video.Media.DATA} LIKE ?"
            }
            val selectionArgs = arrayOf("%My Digital Notes Book%")

            context.contentResolver.query(
                collection,
                projection,
                selection,
                selectionArgs,
                "${MediaStore.Video.Media.DATE_ADDED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val displayCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
                val widthCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH)
                val heightCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val uri = ContentUris.withAppendedId(collection, id)
                    val displayName = cursor.getString(displayCol) ?: "Lecture"
                    val title = cursor.getString(titleCol) ?: displayName.removeSuffix(".mp4")
                    val durationMs = cursor.getLong(durationCol)
                    val sizeBytes = cursor.getLong(sizeCol)
                    val dateAdded = cursor.getLong(dateCol) * 1000L
                    val width = cursor.getInt(widthCol)
                    val height = cursor.getInt(heightCol)

                    val ratio = if (width > 0 && height > 0) {
                        if (width >= height) AspectRatio.RATIO_16_9 else AspectRatio.RATIO_9_16
                    } else AspectRatio.RATIO_16_9

                    val thumbPath = getOrExtractThumbnail(uri, id.toString())

                    results.add(
                        LectureVideo(
                            uriString = uri.toString(),
                            filePath = displayName,
                            title = title,
                            ratio = ratio,
                            durationMs = durationMs,
                            fileSizeBytes = sizeBytes,
                            dateRecorded = dateAdded,
                            thumbnailPath = thumbPath
                        )
                    )
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error querying MediaStore", e)
        }

        // Also check app-specific movies folder
        val moviesDir = File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "My Digital Notes Book")
        if (moviesDir.exists()) {
            moviesDir.listFiles { f -> f.extension.equals("mp4", ignoreCase = true) }?.forEach { f ->
                if (results.none { it.filePath == f.name }) {
                    val uri = Uri.fromFile(f)
                    val thumbPath = getOrExtractThumbnail(uri, f.name)
                    results.add(
                        LectureVideo(
                            uriString = uri.toString(),
                            filePath = f.absolutePath,
                            title = f.nameWithoutExtension,
                            ratio = AspectRatio.RATIO_16_9,
                            durationMs = 0L,
                            fileSizeBytes = f.length(),
                            dateRecorded = f.lastModified(),
                            thumbnailPath = thumbPath
                        )
                    )
                }
            }
        }

        results
    }

    private fun getOrExtractThumbnail(uri: Uri, key: String): String? {
        val thumbFile = File(context.cacheDir, "thumb_$key.jpg")
        if (thumbFile.exists() && thumbFile.length() > 0) {
            return thumbFile.absolutePath
        }

        return try {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(context, uri)
            val frame = retriever.getFrameAtTime(500_000)
            retriever.release()

            if (frame != null) {
                FileOutputStream(thumbFile).use { fos ->
                    frame.compress(Bitmap.CompressFormat.JPEG, 80, fos)
                }
                frame.recycle()
                thumbFile.absolutePath
            } else null
        } catch (e: Exception) {
            null
        }
    }

    suspend fun renameLecture(video: LectureVideo, newTitle: String) = withContext(Dispatchers.IO) {
        val cleanTitle = newTitle.trim()
        if (cleanTitle.isEmpty()) return@withContext

        try {
            val uri = Uri.parse(video.uriString)
            if (uri.scheme == "content") {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.TITLE, cleanTitle)
                    put(MediaStore.Video.Media.DISPLAY_NAME, "$cleanTitle.mp4")
                }
                context.contentResolver.update(uri, values, null, null)
            } else if (uri.scheme == "file") {
                val f = File(video.filePath)
                val newFile = File(f.parentFile, "$cleanTitle.mp4")
                f.renameTo(newFile)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error renaming lecture", e)
        }
        refresh()
    }

    suspend fun deleteLecture(video: LectureVideo) = withContext(Dispatchers.IO) {
        try {
            val uri = Uri.parse(video.uriString)
            if (uri.scheme == "content") {
                context.contentResolver.delete(uri, null, null)
            } else {
                File(video.filePath).delete()
            }
            video.thumbnailPath?.let { File(it).delete() }
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting lecture", e)
        }
        refresh()
    }
}
