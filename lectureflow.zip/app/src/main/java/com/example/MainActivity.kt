package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.AboutScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LecturesScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SlideListScreen
import com.example.ui.screens.StageScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.MainViewModel
import com.example.viewmodel.Screen

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val mainViewModel: MainViewModel = viewModel()
                    val currentScreen by mainViewModel.currentScreen.collectAsState()

                    // Toast and event handler
                    LaunchedEffect(Unit) {
                        mainViewModel.uiEvents.collect { message ->
                            Toast.makeText(this@MainActivity, message, Toast.LENGTH_SHORT).show()
                        }
                    }

                    when (val screen = currentScreen) {
                        is Screen.Home -> {
                            HomeScreen(viewModel = mainViewModel)
                        }
                        is Screen.SlideList -> {
                            SlideListScreen(
                                viewModel = mainViewModel,
                                deckId = screen.deckId
                            )
                        }
                        is Screen.Stage -> {
                            StageScreen(
                                viewModel = mainViewModel,
                                deckId = screen.deckId
                            )
                        }
                        is Screen.Lectures -> {
                            LecturesScreen(viewModel = mainViewModel)
                        }
                        is Screen.Settings -> {
                            SettingsScreen(viewModel = mainViewModel)
                        }
                        is Screen.About -> {
                            AboutScreen(viewModel = mainViewModel)
                        }
                    }
                }
            }
        }
    }
}
