package com.example.model

enum class AspectRatio(val widthRatio: Int, val heightRatio: Int, val label: String) {
    RATIO_16_9(16, 9, "16:9"),
    RATIO_9_16(9, 16, "9:16");

    val isLandscape: Boolean get() = widthRatio > heightRatio

    fun calculateResolution(shortSide: Int): Pair<Int, Int> {
        return when (this) {
            RATIO_16_9 -> {
                val width = (shortSide * 16) / 9
                Pair((width / 2) * 2, (shortSide / 2) * 2)
            }
            RATIO_9_16 -> {
                val height = (shortSide * 16) / 9
                Pair((shortSide / 2) * 2, (height / 2) * 2)
            }
        }
    }
}

enum class SlideSourceType {
    BLANK_WHITE,
    BLANK_DARK,
    IMAGE,
    PDF_PAGE,
    WEB_PAGE
}

enum class ToolType {
    PEN,
    HIGHLIGHTER,
    ERASER,
    SELECT // For selecting, dragging, resizing, or removing overlay images and text
}

data class PointF(val x: Float, val y: Float)

data class Stroke(
    val points: List<PointF>,
    val colorArgb: Int,
    val strokeWidthFraction: Float, // relative to stage width
    val tool: ToolType
)

data class OverlayImage(
    val id: String,
    val imagePath: String,
    val normX: Float, // center X [0..1]
    val normY: Float, // center Y [0..1]
    val normWidth: Float = 0.35f, // fraction of stage width
    val normHeight: Float = 0.35f // fraction of stage height
)

data class OverlayText(
    val id: String,
    val text: String,
    val normX: Float, // center X [0..1]
    val normY: Float, // center Y [0..1]
    val fontSizeSp: Float = 22f,
    val colorArgb: Int,
    val isBold: Boolean = true,
    val hasBackground: Boolean = true
)

data class Slide(
    val id: String,
    val sourceType: SlideSourceType,
    val backgroundPath: String? = null,
    val webUrl: String? = null,
    val overlayImages: List<OverlayImage> = emptyList(),
    val overlayTexts: List<OverlayText> = emptyList(),
    val strokes: List<Stroke> = emptyList()
)

data class Deck(
    val id: String,
    val title: String,
    val ratio: AspectRatio,
    val slides: List<Slide>,
    val updatedAt: Long
)

data class LectureVideo(
    val uriString: String,
    val filePath: String,
    val title: String,
    val ratio: AspectRatio,
    val durationMs: Long,
    val fileSizeBytes: Long,
    val dateRecorded: Long,
    val thumbnailPath: String? = null
)

data class FaceCamBubble(
    val isEnabled: Boolean = false,
    val normCenterX: Float = 0.85f,
    val normCenterY: Float = 0.22f,
    val normRadius: Float = 0.12f
)
