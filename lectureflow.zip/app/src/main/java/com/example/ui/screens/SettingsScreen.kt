package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.AspectRatio
import com.example.settings.AudioBitrateOption
import com.example.settings.AudioSourceOption
import com.example.settings.FpsOption
import com.example.settings.HardwareReport
import com.example.settings.QualityOption
import com.example.settings.RecorderPreferences
import com.example.settings.VideoBitrateOption
import com.example.settings.VideoCodecOption
import com.example.viewmodel.MainViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    val config by viewModel.recorderConfig.collectAsState()
    var hardwareReport by remember { mutableStateOf<HardwareReport?>(null) }

    BackHandler {
        viewModel.navigateBack()
    }

    Scaffold(
        modifier = modifier.testTag("settings_screen"),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = stringResource(R.string.settings_title),
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Section 1: Audio Configuration
            item {
                Text(
                    text = stringResource(R.string.settings_section_audio),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = stringResource(R.string.settings_audio_source),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        AudioSourceOption.values().forEach { option ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        scope.launch { viewModel.recorderPreferences.updateAudioSource(option) }
                                    }
                                    .padding(vertical = 4.dp)
                            ) {
                                RadioButton(
                                    selected = config.audioSource == option,
                                    onClick = {
                                        scope.launch { viewModel.recorderPreferences.updateAudioSource(option) }
                                    }
                                )
                                Text(
                                    text = if (option == AudioSourceOption.MIC)
                                        stringResource(R.string.settings_audio_source_mic)
                                    else stringResource(R.string.settings_audio_source_camcorder),
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                        Text(
                            text = stringResource(R.string.settings_audio_bitrate),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            AudioBitrateOption.values().forEach { option ->
                                OutlinedButton(
                                    onClick = {
                                        scope.launch { viewModel.recorderPreferences.updateAudioBitrate(option) }
                                    },
                                    colors = if (config.audioBitrate == option) {
                                        ButtonDefaults.outlinedButtonColors(
                                            containerColor = MaterialTheme.colorScheme.primaryContainer,
                                            contentColor = MaterialTheme.colorScheme.primary
                                        )
                                    } else ButtonDefaults.outlinedButtonColors()
                                ) {
                                    Text("${option.kbps} kbps")
                                }
                            }
                        }
                    }
                }
            }

            // Section 2: Video Encoding
            item {
                Text(
                    text = stringResource(R.string.settings_section_video),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        // Video Codec
                        Text(
                            text = stringResource(R.string.settings_video_codec),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        VideoCodecOption.values().forEach { option ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        scope.launch { viewModel.recorderPreferences.updateVideoCodec(option) }
                                    }
                                    .padding(vertical = 4.dp)
                            ) {
                                RadioButton(
                                    selected = config.videoCodec == option,
                                    onClick = {
                                        scope.launch { viewModel.recorderPreferences.updateVideoCodec(option) }
                                    }
                                )
                                Text(
                                    text = if (option == VideoCodecOption.H264)
                                        stringResource(R.string.settings_video_codec_h264)
                                    else stringResource(R.string.settings_video_codec_hevc),
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                        // Quality / Resolution
                        Text(
                            text = stringResource(R.string.settings_quality),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        QualityOption.values().forEach { option ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        scope.launch { viewModel.recorderPreferences.updateQuality(option) }
                                    }
                                    .padding(vertical = 4.dp)
                            ) {
                                RadioButton(
                                    selected = config.quality == option,
                                    onClick = {
                                        scope.launch { viewModel.recorderPreferences.updateQuality(option) }
                                    }
                                )
                                Text(
                                    text = if (option == QualityOption.P720)
                                        stringResource(R.string.settings_quality_720)
                                    else stringResource(R.string.settings_quality_1080),
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                        // Target FPS
                        Text(
                            text = stringResource(R.string.settings_fps),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FpsOption.values().forEach { option ->
                                OutlinedButton(
                                    onClick = {
                                        scope.launch { viewModel.recorderPreferences.updateFps(option) }
                                    },
                                    colors = if (config.fps == option) {
                                        ButtonDefaults.outlinedButtonColors(
                                            containerColor = MaterialTheme.colorScheme.primaryContainer,
                                            contentColor = MaterialTheme.colorScheme.primary
                                        )
                                    } else ButtonDefaults.outlinedButtonColors()
                                ) {
                                    Text("${option.fps} fps")
                                }
                            }
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                        // Video Bitrate
                        Text(
                            text = stringResource(R.string.settings_bitrate),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            VideoBitrateOption.values().forEach { option ->
                                OutlinedButton(
                                    onClick = {
                                        scope.launch { viewModel.recorderPreferences.updateVideoBitrate(option) }
                                    },
                                    colors = if (config.videoBitrate == option) {
                                        ButtonDefaults.outlinedButtonColors(
                                            containerColor = MaterialTheme.colorScheme.primaryContainer,
                                            contentColor = MaterialTheme.colorScheme.primary
                                        )
                                    } else ButtonDefaults.outlinedButtonColors()
                                ) {
                                    Text("${option.mbps} Mbps")
                                }
                            }
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                        // Default Aspect Ratio
                        Text(
                            text = stringResource(R.string.settings_default_ratio),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(
                                selected = config.defaultRatio == AspectRatio.RATIO_16_9,
                                onClick = {
                                    scope.launch { viewModel.recorderPreferences.updateDefaultRatio(AspectRatio.RATIO_16_9) }
                                }
                            )
                            Text(
                                text = "16:9 Landscape",
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.clickable {
                                    scope.launch { viewModel.recorderPreferences.updateDefaultRatio(AspectRatio.RATIO_16_9) }
                                }
                            )
                            Spacer(modifier = Modifier.padding(horizontal = 8.dp))
                            RadioButton(
                                selected = config.defaultRatio == AspectRatio.RATIO_9_16,
                                onClick = {
                                    scope.launch { viewModel.recorderPreferences.updateDefaultRatio(AspectRatio.RATIO_9_16) }
                                }
                            )
                            Text(
                                text = "9:16 Portrait",
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.clickable {
                                    scope.launch { viewModel.recorderPreferences.updateDefaultRatio(AspectRatio.RATIO_9_16) }
                                }
                            )
                        }
                    }
                }
            }

            // Section 3: Action Buttons (Reset & Test My Phone)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            hardwareReport = RecorderPreferences.testHardwareCapabilities()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_test_phone")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Build,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.padding(horizontal = 4.dp))
                        Text(stringResource(R.string.settings_btn_test_phone))
                    }

                    OutlinedButton(
                        onClick = {
                            scope.launch { viewModel.recorderPreferences.resetToDefaults() }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_reset_defaults")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.padding(horizontal = 4.dp))
                        Text(stringResource(R.string.settings_btn_reset))
                    }
                }
            }
        }
    }

    // Hardware Capability Test Dialog
    hardwareReport?.let { report ->
        AlertDialog(
            onDismissRequest = { hardwareReport = null },
            title = { Text(stringResource(R.string.test_phone_dialog_title)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Hardware Video Capabilities:",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text("• H.264 (AVC): ${if (report.h264Supported) "Supported (Up to ${report.h264MaxResolution}, ${report.maxFpsH264}fps)" else "Not supported"}")
                    Text("• H.265 (HEVC): ${if (report.hevcSupported) "Supported (Up to ${report.hevcMaxResolution}, ${report.maxFpsHevc}fps)" else "Not supported"}")
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = stringResource(R.string.codec_fallback_notice),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Button(onClick = { hardwareReport = null }) {
                    Text(stringResource(R.string.test_phone_dialog_close))
                }
            }
        )
    }
}
