package com.example.ui.screens

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.net.Uri
import android.os.Build
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.Highlight
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Screenshot
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.example.R
import com.example.camera.FaceCamManager
import com.example.model.AspectRatio
import com.example.model.OverlayImage
import com.example.model.OverlayText
import com.example.model.PointF
import com.example.model.Slide
import com.example.model.SlideSourceType
import com.example.model.Stroke
import com.example.model.ToolType
import com.example.recorder.RecorderState
import com.example.renderer.StageRenderer
import com.example.viewmodel.MainViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StageScreen(
    viewModel: MainViewModel,
    deckId: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val activity = context as? Activity

    val deck by viewModel.activeDeck.collectAsState()
    val activeDeck = deck ?: return

    val currentSlideIndex by viewModel.currentSlideIndex.collectAsState()
    val currentStrokes by viewModel.currentStrokes.collectAsState()
    val currentOverlayImages by viewModel.currentOverlayImages.collectAsState()
    val currentOverlayTexts by viewModel.currentOverlayTexts.collectAsState()
    val selectedElementId by viewModel.selectedElementId.collectAsState()

    val activeTool by viewModel.activeTool.collectAsState()
    val selectedColorArgb by viewModel.selectedColorArgb.collectAsState()
    val strokeWidthFraction by viewModel.strokeWidthFraction.collectAsState()
    val faceCamBubble by viewModel.faceCamBubble.collectAsState()
    val isToolbarVisible by viewModel.isToolbarVisible.collectAsState()
    val isWebBrowseMode by viewModel.isWebBrowseMode.collectAsState()
    val recorderState by viewModel.recorderState.collectAsState()

    val currentSlide = activeDeck.slides.getOrNull(currentSlideIndex) ?: return

    // Face-Cam Manager
    val faceCamManager = remember { FaceCamManager(context) }
    var currentFaceCamBitmap by remember { mutableStateOf<Bitmap?>(null) }

    // Cached background bitmap for image / PDF slide
    var slideBackgroundBitmap by remember { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(currentSlide.id, currentSlide.backgroundPath) {
        slideBackgroundBitmap?.recycle()
        slideBackgroundBitmap = null
        if (currentSlide.backgroundPath != null) {
            val file = File(currentSlide.backgroundPath)
            if (file.exists()) {
                slideBackgroundBitmap = BitmapFactory.decodeFile(file.absolutePath)
            }
        }
    }

    // Reusable Web Snapshot Bitmap
    var webSnapshotBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var webUrlInput by remember { mutableStateOf(currentSlide.webUrl ?: "https://en.wikipedia.org") }

    // Web periodic snapshot loop for video recording
    LaunchedEffect(currentSlide.sourceType, webViewRef) {
        if (currentSlide.sourceType == SlideSourceType.WEB_PAGE) {
            while (isActive) {
                delay(66) // ~15 fps web capture
                webViewRef?.let { wv ->
                    if (wv.width > 0 && wv.height > 0) {
                        try {
                            val bmp = webSnapshotBitmap ?: Bitmap.createBitmap(
                                wv.width,
                                wv.height,
                                Bitmap.Config.ARGB_8888
                            ).also { webSnapshotBitmap = it }
                            val c = Canvas(bmp)
                            wv.draw(c)
                        } catch (ignored: Exception) {
                        }
                    }
                }
            }
        }
    }

    // Image Picker for adding overlay sticker/photo onto slide
    val overlayImagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        uri?.let {
            viewModel.addOverlayImage(it)
        }
    }

    // PDF Import Launcher right from stage
    val stagePdfPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            viewModel.importPdfToDeck(
                title = activeDeck.title,
                ratio = activeDeck.ratio,
                uri = it,
                targetDeckId = deckId
            )
        }
    }

    // Permissions Launchers
    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasMicPermission = granted
        if (granted) {
            startStageRecording(viewModel, currentSlide, slideBackgroundBitmap, webSnapshotBitmap, currentFaceCamBitmap)
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
        if (granted) {
            viewModel.toggleFaceCam(true)
            faceCamManager.start(lifecycleOwner) { bmp ->
                currentFaceCamBitmap = bmp
            }
        }
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { /* result noted */ }

    // Keep screen on & lock orientation according to aspect ratio
    DisposableEffect(activeDeck.ratio) {
        val originalOrientation = activity?.requestedOrientation ?: ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        activity?.requestedOrientation = if (activeDeck.ratio == AspectRatio.RATIO_16_9) {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        } else {
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        onDispose {
            activity?.requestedOrientation = originalOrientation
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            faceCamManager.stop()
            slideBackgroundBitmap?.recycle()
            webSnapshotBitmap?.recycle()
        }
    }

    // Active stroke in progress on screen
    var inProgressPoints by remember { mutableStateOf<List<PointF>>(emptyList()) }

    // Dialogs & Menus
    var showExitDialog by remember { mutableStateOf(false) }
    var showAddTextDialog by remember { mutableStateOf(false) }
    var showClearMenu by remember { mutableStateOf(false) }

    BackHandler {
        if (recorderState is RecorderState.Recording || recorderState is RecorderState.Paused) {
            showExitDialog = true
        } else {
            viewModel.saveCurrentSlideElements()
            viewModel.navigateBack()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F1117))
            .testTag("stage_screen")
    ) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val density = LocalDensity.current
            val totalW = maxWidth
            val totalH = maxHeight

            // Target aspect ratio calculation
            val targetAspect = if (activeDeck.ratio == AspectRatio.RATIO_16_9) 16f / 9f else 9f / 16f

            // Reserve room outside stage for toolbar
            val toolbarBreadth = if (isToolbarVisible) 58.dp else 0.dp
            val availableW = totalW
            val availableH = totalH - toolbarBreadth

            val stageW: androidx.compose.ui.unit.Dp
            val stageH: androidx.compose.ui.unit.Dp

            if (availableW / availableH > targetAspect) {
                stageH = availableH
                stageW = availableH * targetAspect
            } else {
                stageW = availableW
                stageH = availableW / targetAspect
            }

            val stageWidthPx = with(density) { stageW.toPx() }
            val stageHeightPx = with(density) { stageH.toPx() }

            // Stage Container (Centered, Exact Ratio)
            Box(
                modifier = Modifier
                    .size(stageW, stageH)
                    .align(Alignment.Center)
                    .clip(RoundedCornerShape(4.dp))
                    .background(
                        when (currentSlide.sourceType) {
                            SlideSourceType.BLANK_DARK -> Color(0xFF12141C)
                            else -> Color.White
                        }
                    )
                    .border(1.5.dp, Color(0xFF2A2E3D), RoundedCornerShape(4.dp))
                    .testTag("stage_viewport")
            ) {
                // 1. Background image / PDF rendering
                if (currentSlide.backgroundPath != null) {
                    AsyncImage(
                        model = currentSlide.backgroundPath,
                        contentDescription = "Slide background",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                // 2. Web page slide inside stage
                if (currentSlide.sourceType == SlideSourceType.WEB_PAGE) {
                    AndroidView(
                        factory = { ctx ->
                            WebView(ctx).apply {
                                layoutParams = ViewGroup.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT
                                )
                                settings.javaScriptEnabled = true
                                settings.domStorageEnabled = true
                                webViewClient = WebViewClient()
                                loadUrl(currentSlide.webUrl ?: "https://en.wikipedia.org")
                                webViewRef = this
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                // 3. Overlay Images (Cutouts, illustrations, photos)
                currentOverlayImages.forEach { img ->
                    val isSelected = selectedElementId == img.id
                    val imgWPx = stageWidthPx * img.normWidth
                    val imgHPx = stageHeightPx * img.normHeight
                    val imgCenterX = stageWidthPx * img.normX
                    val imgCenterY = stageHeightPx * img.normY
                    val leftDp = with(density) { (imgCenterX - imgWPx / 2f).toDp() }
                    val topDp = with(density) { (imgCenterY - imgHPx / 2f).toDp() }
                    val wDp = with(density) { imgWPx.toDp() }
                    val hDp = with(density) { imgHPx.toDp() }

                    Box(
                        modifier = Modifier
                            .offset(x = leftDp, y = topDp)
                            .size(wDp, hDp)
                            .then(
                                if (isSelected) {
                                    Modifier.border(2.dp, MaterialTheme.colorScheme.secondary, RoundedCornerShape(4.dp))
                                } else Modifier
                            )
                            .pointerInput(img.id) {
                                detectDragGestures(
                                    onDragStart = {
                                        viewModel.selectElement(img.id)
                                    },
                                    onDrag = { change, dragAmount ->
                                        change.consume()
                                        val newNormX = (img.normX + dragAmount.x / stageWidthPx).coerceIn(0.05f, 0.95f)
                                        val newNormY = (img.normY + dragAmount.y / stageHeightPx).coerceIn(0.05f, 0.95f)
                                        viewModel.updateOverlayImage(img.copy(normX = newNormX, normY = newNormY))
                                    }
                                )
                            }
                    ) {
                        AsyncImage(
                            model = img.imagePath,
                            contentDescription = "Overlay Image",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize()
                        )

                        // Floating action controls when selected
                        if (isSelected) {
                            Row(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .offset(y = (-32).dp)
                                    .background(Color(0xE012141C), RoundedCornerShape(8.dp))
                                    .padding(2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(
                                    onClick = {
                                        val newW = (img.normWidth * 0.85f).coerceAtLeast(0.1f)
                                        val newH = (img.normHeight * 0.85f).coerceAtLeast(0.1f)
                                        viewModel.updateOverlayImage(img.copy(normWidth = newW, normHeight = newH))
                                    },
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Icon(Icons.Default.Remove, contentDescription = "Smaller", tint = Color.White, modifier = Modifier.size(16.dp))
                                }
                                IconButton(
                                    onClick = {
                                        val newW = (img.normWidth * 1.15f).coerceAtMost(0.9f)
                                        val newH = (img.normHeight * 1.15f).coerceAtMost(0.9f)
                                        viewModel.updateOverlayImage(img.copy(normWidth = newW, normHeight = newH))
                                    },
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = "Larger", tint = Color.White, modifier = Modifier.size(16.dp))
                                }
                                IconButton(
                                    onClick = { viewModel.deleteOverlayImage(img.id) },
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                                }
                                IconButton(
                                    onClick = { viewModel.selectElement(null) },
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = "Done", tint = Color.Green, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }

                // 4. Overlay Texts (Customizable text boxes)
                currentOverlayTexts.forEach { txt ->
                    val isSelected = selectedElementId == txt.id
                    val txtCenterX = stageWidthPx * txt.normX
                    val txtCenterY = stageHeightPx * txt.normY
                    val centerXDp = with(density) { txtCenterX.toDp() }
                    val centerYDp = with(density) { txtCenterY.toDp() }

                    Box(
                        modifier = Modifier
                            .offset {
                                IntOffset(
                                    (txtCenterX - 80).roundToInt(),
                                    (txtCenterY - 25).roundToInt()
                                )
                            }
                            .pointerInput(txt.id) {
                                detectDragGestures(
                                    onDragStart = {
                                        viewModel.selectElement(txt.id)
                                    },
                                    onDrag = { change, dragAmount ->
                                        change.consume()
                                        val newNormX = (txt.normX + dragAmount.x / stageWidthPx).coerceIn(0.05f, 0.95f)
                                        val newNormY = (txt.normY + dragAmount.y / stageHeightPx).coerceIn(0.05f, 0.95f)
                                        viewModel.updateOverlayText(txt.copy(normX = newNormX, normY = newNormY))
                                    }
                                )
                            }
                    ) {
                        Surface(
                            color = if (txt.hasBackground) {
                                val isLight = Color(txt.colorArgb).let { (it.red + it.green + it.blue) > 1.5f }
                                if (isLight) Color(0xD012141C) else Color(0xEEFFFFFF)
                            } else Color.Transparent,
                            shape = RoundedCornerShape(8.dp),
                            border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, MaterialTheme.colorScheme.secondary) else null,
                            modifier = Modifier.padding(4.dp)
                        ) {
                            Text(
                                text = txt.text,
                                color = Color(txt.colorArgb),
                                fontSize = txt.fontSizeSp.sp,
                                fontWeight = if (txt.isBold) FontWeight.Bold else FontWeight.Normal,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }

                        // Floating action controls for text when selected
                        if (isSelected) {
                            Row(
                                modifier = Modifier
                                    .align(Alignment.TopCenter)
                                    .offset(y = (-32).dp)
                                    .background(Color(0xE012141C), RoundedCornerShape(8.dp))
                                    .padding(2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(
                                    onClick = {
                                        val newSize = (txt.fontSizeSp - 3f).coerceAtLeast(12f)
                                        viewModel.updateOverlayText(txt.copy(fontSizeSp = newSize))
                                    },
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Icon(Icons.Default.Remove, contentDescription = "Smaller", tint = Color.White, modifier = Modifier.size(16.dp))
                                }
                                IconButton(
                                    onClick = {
                                        val newSize = (txt.fontSizeSp + 3f).coerceAtMost(48f)
                                        viewModel.updateOverlayText(txt.copy(fontSizeSp = newSize))
                                    },
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = "Larger", tint = Color.White, modifier = Modifier.size(16.dp))
                                }
                                IconButton(
                                    onClick = { viewModel.deleteOverlayText(txt.id) },
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                                }
                                IconButton(
                                    onClick = { viewModel.selectElement(null) },
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = "Done", tint = Color.Green, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }

                // 5. Drawing Canvas overlay (paints strokes ON TOP of PDF, images, and text)
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(isWebBrowseMode, activeTool, selectedColorArgb, strokeWidthFraction) {
                            if (!isWebBrowseMode && activeTool != ToolType.SELECT) {
                                detectDragGestures(
                                    onDragStart = { offset ->
                                        val normX = (offset.x / stageWidthPx).coerceIn(0f, 1f)
                                        val normY = (offset.y / stageHeightPx).coerceIn(0f, 1f)
                                        inProgressPoints = listOf(PointF(normX, normY))
                                    },
                                    onDrag = { change, _ ->
                                        change.consume()
                                        val normX = (change.position.x / stageWidthPx).coerceIn(0f, 1f)
                                        val normY = (change.position.y / stageHeightPx).coerceIn(0f, 1f)
                                        inProgressPoints = inProgressPoints + PointF(normX, normY)
                                    },
                                    onDragEnd = {
                                        if (inProgressPoints.isNotEmpty()) {
                                            viewModel.addStroke(
                                                Stroke(
                                                    points = inProgressPoints,
                                                    colorArgb = selectedColorArgb,
                                                    strokeWidthFraction = strokeWidthFraction,
                                                    tool = activeTool
                                                )
                                            )
                                            inProgressPoints = emptyList()
                                        }
                                    },
                                    onDragCancel = {
                                        inProgressPoints = emptyList()
                                    }
                                )
                            }
                        }
                ) {
                    val canvasNative = drawContext.canvas.nativeCanvas
                    val w = size.width
                    val h = size.height

                    // Render existing slide strokes
                    StageRenderer.drawStrokes(canvasNative, currentStrokes, w, h, currentSlide.sourceType)

                    // Render active in-progress stroke
                    if (inProgressPoints.isNotEmpty()) {
                        val activeStroke = Stroke(
                            points = inProgressPoints,
                            colorArgb = selectedColorArgb,
                            strokeWidthFraction = strokeWidthFraction,
                            tool = activeTool
                        )
                        StageRenderer.drawStrokes(canvasNative, listOf(activeStroke), w, h, currentSlide.sourceType)
                    }
                }

                // 6. Draggable Face-Cam Bubble
                if (faceCamBubble.isEnabled) {
                    val bubbleRadiusPx = stageWidthPx * faceCamBubble.normRadius
                    val bubbleDiameterDp = with(density) { (bubbleRadiusPx * 2).toDp() }
                    val bubbleCenterXPx = stageWidthPx * faceCamBubble.normCenterX
                    val bubbleCenterYPx = stageHeightPx * faceCamBubble.normCenterY
                    val offsetX = with(density) { (bubbleCenterXPx - bubbleRadiusPx).toDp() }
                    val offsetY = with(density) { (bubbleCenterYPx - bubbleRadiusPx).toDp() }

                    Box(
                        modifier = Modifier
                            .offset(x = offsetX, y = offsetY)
                            .size(bubbleDiameterDp)
                            .clip(CircleShape)
                            .border(3.dp, MaterialTheme.colorScheme.secondary, CircleShape)
                            .pointerInput(Unit) {
                                detectDragGestures { change, dragAmount ->
                                    change.consume()
                                    val newNormX = faceCamBubble.normCenterX + (dragAmount.x / stageWidthPx)
                                    val newNormY = faceCamBubble.normCenterY + (dragAmount.y / stageHeightPx)
                                    viewModel.updateFaceCamPosition(newNormX, newNormY)
                                }
                            }
                    ) {
                        if (currentFaceCamBitmap != null && !currentFaceCamBitmap!!.isRecycled) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                currentFaceCamBitmap?.let { bmp ->
                                    val src = android.graphics.Rect(0, 0, bmp.width, bmp.height)
                                    val dst = android.graphics.Rect(0, 0, size.width.toInt(), size.height.toInt())
                                    drawContext.canvas.nativeCanvas.drawBitmap(bmp, src, dst, null)
                                }
                            }
                        } else {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color.Black.copy(alpha = 0.7f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CameraAlt,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                    }
                }

                // REC badge & timer inside stage top-right corner
                if (recorderState is RecorderState.Recording || recorderState is RecorderState.Paused) {
                    val timeText = when (val s = recorderState) {
                        is RecorderState.Recording -> s.formattedTime
                        is RecorderState.Paused -> s.formattedTime
                        else -> "00:00:00"
                    }
                    val isPaused = recorderState is RecorderState.Paused

                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(10.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isPaused) Color(0xCCFF9800) else Color(0xCCE53935))
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(Color.White)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isPaused) "PAUSED $timeText" else "REC $timeText",
                                color = Color.White,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Web Address Bar & Mode Toggle (OUTSIDE the stage rectangle)
            if (currentSlide.sourceType == SlideSourceType.WEB_PAGE) {
                Surface(
                    color = Color(0xFF1E2230),
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = webUrlInput,
                            onValueChange = { webUrlInput = it },
                            placeholder = { Text(stringResource(R.string.web_url_hint)) },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Button(
                            onClick = { webViewRef?.loadUrl(webUrlInput) },
                            modifier = Modifier.height(42.dp)
                        ) {
                            Text(stringResource(R.string.web_go))
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { viewModel.toggleWebBrowseMode() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isWebBrowseMode) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary
                            ),
                            modifier = Modifier.height(42.dp)
                        ) {
                            Icon(
                                imageVector = if (isWebBrowseMode) Icons.Default.TouchApp else Icons.Default.Edit,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                if (isWebBrowseMode) stringResource(R.string.web_mode_browse)
                                else stringResource(R.string.web_mode_draw)
                            )
                        }
                    }
                }
            }

            // Main Toolbar (OUTSIDE the stage rectangle, along the bottom edge)
            AnimatedVisibility(
                visible = isToolbarVisible,
                enter = fadeIn() + scaleIn(),
                exit = fadeOut() + scaleOut(),
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
            ) {
                StageToolbar(
                    activeTool = activeTool,
                    selectedColorArgb = selectedColorArgb,
                    strokeWidthFraction = strokeWidthFraction,
                    faceCamEnabled = faceCamBubble.isEnabled,
                    recorderState = recorderState,
                    currentSlideIndex = currentSlideIndex,
                    totalSlides = activeDeck.slides.size,
                    hasOverlays = currentOverlayTexts.isNotEmpty() || currentOverlayImages.isNotEmpty(),
                    onSelectTool = { viewModel.setActiveTool(it) },
                    onSelectColor = { viewModel.setSelectedColorArgb(it) },
                    onSelectWidth = { viewModel.setStrokeWidthFraction(it) },
                    onAddText = { showAddTextDialog = true },
                    onAddImage = {
                        overlayImagePickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    onAddPdf = {
                        stagePdfPickerLauncher.launch("application/pdf")
                    },
                    onUndo = { viewModel.undo() },
                    onRedo = { viewModel.redo() },
                    onOpenClearMenu = { showClearMenu = true },
                    onPrevSlide = { viewModel.switchSlide(currentSlideIndex - 1) },
                    onNextSlide = { viewModel.switchSlide(currentSlideIndex + 1) },
                    onScreenshot = {
                        viewModel.takeScreenshot(
                            stageWidth = stageWidthPx.toInt(),
                            stageHeight = stageHeightPx.toInt(),
                            backgroundBitmap = slideBackgroundBitmap,
                            webViewBitmap = webSnapshotBitmap,
                            faceCamBitmap = currentFaceCamBitmap
                        )
                    },
                    onToggleFaceCam = {
                        if (!faceCamBubble.isEnabled) {
                            if (hasCameraPermission) {
                                viewModel.toggleFaceCam(true)
                                faceCamManager.start(lifecycleOwner) { bmp ->
                                    currentFaceCamBitmap = bmp
                                }
                            } else {
                                cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                            }
                        } else {
                            viewModel.toggleFaceCam(false)
                            faceCamManager.stop()
                        }
                    },
                    onRecordClick = {
                        when (recorderState) {
                            is RecorderState.Idle -> {
                                if (hasMicPermission) {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                    }
                                    startStageRecording(
                                        viewModel,
                                        currentSlide,
                                        slideBackgroundBitmap,
                                        webSnapshotBitmap,
                                        currentFaceCamBitmap
                                    )
                                } else {
                                    micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }
                            }
                            is RecorderState.Recording -> {
                                viewModel.pauseRecording()
                            }
                            is RecorderState.Paused -> {
                                viewModel.resumeRecording()
                            }
                            else -> {}
                        }
                    },
                    onStopRecord = {
                        viewModel.stopRecording()
                    },
                    onToggleHideToolbar = {
                        viewModel.toggleToolbarVisibility()
                    }
                )
            }

            // Toolbar Floating Unhide Button (shown when toolbar is hidden)
            if (!isToolbarVisible) {
                IconButton(
                    onClick = { viewModel.toggleToolbarVisibility() },
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(16.dp)
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.7f))
                ) {
                    Icon(
                        imageVector = Icons.Default.Visibility,
                        contentDescription = "Show Tools",
                        tint = Color.White
                    )
                }
            }

            // Back button (top-left outside stage)
            IconButton(
                onClick = {
                    if (recorderState is RecorderState.Recording || recorderState is RecorderState.Paused) {
                        showExitDialog = true
                    } else {
                        viewModel.saveCurrentSlideElements()
                        viewModel.navigateBack()
                    }
                },
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(8.dp)
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.6f))
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = Color.White
                )
            }

            // 3-2-1 Countdown Overlay
            if (recorderState is RecorderState.Countdown) {
                val sec = (recorderState as RecorderState.Countdown).secondsLeft
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.6f)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = stringResource(R.string.countdown_ready),
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White.copy(alpha = 0.8f)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "$sec",
                            style = MaterialTheme.typography.displayLarge.copy(fontSize = 96.sp),
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                }
            }

            // Saving Progress Overlay
            if (recorderState is RecorderState.Saving) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.75f)),
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = stringResource(R.string.recording_saving),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }

    // Add Text Dialog
    if (showAddTextDialog) {
        var textContent by remember { mutableStateOf("") }
        var chosenColor by remember { mutableStateOf(selectedColorArgb) }
        var chosenFontSize by remember { mutableStateOf(24f) }

        val palette = listOf(
            android.graphics.Color.WHITE,
            android.graphics.Color.parseColor("#283593"),
            android.graphics.Color.parseColor("#FF5722"),
            android.graphics.Color.parseColor("#2E7D32"),
            android.graphics.Color.parseColor("#F57F17"),
            android.graphics.Color.parseColor("#D50000"),
            android.graphics.Color.parseColor("#212121")
        )

        AlertDialog(
            onDismissRequest = { showAddTextDialog = false },
            title = { Text(stringResource(R.string.dialog_add_text_title)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = textContent,
                        onValueChange = { textContent = it },
                        placeholder = { Text(stringResource(R.string.dialog_add_text_hint)) },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 4
                    )

                    Text("Text Color:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        palette.forEach { argb ->
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(Color(argb))
                                    .clickable { chosenColor = argb }
                                    .border(
                                        if (chosenColor == argb) 2.dp else 1.dp,
                                        if (chosenColor == argb) MaterialTheme.colorScheme.primary else Color.Gray,
                                        CircleShape
                                    )
                            )
                        }
                    }

                    Text("Size:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(18f to "Small", 24f to "Medium", 32f to "Large").forEach { (sz, lbl) ->
                            OutlinedButton(
                                onClick = { chosenFontSize = sz },
                                colors = if (chosenFontSize == sz) ButtonDefaults.outlinedButtonColors(
                                    containerColor = MaterialTheme.colorScheme.primaryContainer
                                ) else ButtonDefaults.outlinedButtonColors()
                            ) {
                                Text(lbl)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (textContent.isNotBlank()) {
                            viewModel.addOverlayText(textContent, chosenColor, chosenFontSize)
                            showAddTextDialog = false
                        }
                    }
                ) {
                    Text("Add Text")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddTextDialog = false }) {
                    Text(stringResource(R.string.btn_cancel))
                }
            }
        )
    }

    // Clear Options Dropdown Dialog
    if (showClearMenu) {
        AlertDialog(
            onDismissRequest = { showClearMenu = false },
            title = { Text(stringResource(R.string.stage_action_clear)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            viewModel.clearAllTexts()
                            showClearMenu = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.TextFields, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(stringResource(R.string.action_clear_all_text))
                    }

                    Button(
                        onClick = {
                            viewModel.clearPage()
                            showClearMenu = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(stringResource(R.string.action_clear_strokes))
                    }

                    OutlinedButton(
                        onClick = {
                            viewModel.clearAllImages()
                            showClearMenu = false
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Image, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(stringResource(R.string.action_clear_all_images))
                    }

                    Button(
                        onClick = {
                            viewModel.clearAllSlideAnnotations()
                            showClearMenu = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(stringResource(R.string.action_clear_everything))
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showClearMenu = false }) {
                    Text(stringResource(R.string.btn_cancel))
                }
            }
        )
    }

    // Pause Dialog (with STOP and RESUME)
    if (recorderState is RecorderState.Paused) {
        val pausedState = recorderState as RecorderState.Paused
        AlertDialog(
            onDismissRequest = { },
            title = { Text(stringResource(R.string.dialog_pause_title)) },
            text = {
                Text(
                    stringResource(
                        R.string.dialog_pause_message,
                        pausedState.formattedTime
                    ) + (pausedState.reason?.let { "\n($it)" } ?: "")
                )
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.resumeRecording() },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text(stringResource(R.string.record_resume))
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { viewModel.stopRecording() }
                ) {
                    Text(stringResource(R.string.record_stop))
                }
            }
        )
    }

    // Exit While Recording Confirmation Dialog
    if (showExitDialog) {
        AlertDialog(
            onDismissRequest = { showExitDialog = false },
            title = { Text(stringResource(R.string.dialog_exit_recording_title)) },
            text = { Text(stringResource(R.string.dialog_exit_recording_desc)) },
            confirmButton = {
                Button(
                    onClick = {
                        showExitDialog = false
                        viewModel.stopRecording()
                        viewModel.navigateBack()
                    }
                ) {
                    Text(stringResource(R.string.btn_save_and_exit))
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showExitDialog = false
                        viewModel.discardRecording()
                        viewModel.navigateBack()
                    }
                ) {
                    Text(stringResource(R.string.btn_discard))
                }
            }
        )
    }
}

private fun startStageRecording(
    viewModel: MainViewModel,
    slide: Slide,
    backgroundBitmap: Bitmap?,
    webViewBitmap: Bitmap?,
    faceCamBitmap: Bitmap?
) {
    viewModel.startRecording { canvas, width, height ->
        StageRenderer.render(
            canvas = canvas,
            w = width,
            h = height,
            slide = slide.copy(
                strokes = viewModel.currentStrokes.value,
                overlayImages = viewModel.currentOverlayImages.value,
                overlayTexts = viewModel.currentOverlayTexts.value
            ),
            strokes = viewModel.currentStrokes.value,
            backgroundBitmap = backgroundBitmap,
            webViewBitmap = webViewBitmap,
            faceCamBitmap = faceCamBitmap,
            faceCamBubble = viewModel.faceCamBubble.value
        )
    }
}

@Composable
private fun StageToolbar(
    activeTool: ToolType,
    selectedColorArgb: Int,
    strokeWidthFraction: Float,
    faceCamEnabled: Boolean,
    recorderState: RecorderState,
    currentSlideIndex: Int,
    totalSlides: Int,
    hasOverlays: Boolean,
    onSelectTool: (ToolType) -> Unit,
    onSelectColor: (Int) -> Unit,
    onSelectWidth: (Float) -> Unit,
    onAddText: () -> Unit,
    onAddImage: () -> Unit,
    onAddPdf: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onOpenClearMenu: () -> Unit,
    onPrevSlide: () -> Unit,
    onNextSlide: () -> Unit,
    onScreenshot: () -> Unit,
    onToggleFaceCam: () -> Unit,
    onRecordClick: () -> Unit,
    onStopRecord: () -> Unit,
    onToggleHideToolbar: () -> Unit
) {
    val drawingColors = listOf(
        android.graphics.Color.parseColor("#283593"),
        android.graphics.Color.parseColor("#FF5722"),
        android.graphics.Color.parseColor("#2E7D32"),
        android.graphics.Color.parseColor("#F57F17"),
        android.graphics.Color.parseColor("#D50000"),
        android.graphics.Color.parseColor("#212121"),
        android.graphics.Color.WHITE
    )

    Surface(
        color = Color(0xF2181B24),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("stage_toolbar")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Tools: Pen, Highlighter, Eraser, Select/Move, Add Text, Add Image, Add PDF
            Row(verticalAlignment = Alignment.CenterVertically) {
                ToolIconButton(
                    icon = Icons.Default.Edit,
                    isSelected = activeTool == ToolType.PEN,
                    onClick = { onSelectTool(ToolType.PEN) },
                    contentDesc = "Pen"
                )
                ToolIconButton(
                    icon = Icons.Default.Highlight,
                    isSelected = activeTool == ToolType.HIGHLIGHTER,
                    onClick = { onSelectTool(ToolType.HIGHLIGHTER) },
                    contentDesc = "Highlighter"
                )
                ToolIconButton(
                    icon = Icons.Default.Clear,
                    isSelected = activeTool == ToolType.ERASER,
                    onClick = { onSelectTool(ToolType.ERASER) },
                    contentDesc = "Eraser"
                )
                ToolIconButton(
                    icon = Icons.Default.NearMe,
                    isSelected = activeTool == ToolType.SELECT,
                    onClick = { onSelectTool(ToolType.SELECT) },
                    contentDesc = "Select / Move Elements"
                )

                Spacer(modifier = Modifier.width(4.dp))

                // Text insertion button
                ToolIconButton(
                    icon = Icons.Default.TextFields,
                    isSelected = false,
                    onClick = onAddText,
                    contentDesc = "Add Text"
                )

                // Image sticker button
                ToolIconButton(
                    icon = Icons.Default.AddPhotoAlternate,
                    isSelected = false,
                    onClick = onAddImage,
                    contentDesc = "Add Image"
                )

                // PDF quick add button
                ToolIconButton(
                    icon = Icons.Default.PictureAsPdf,
                    isSelected = false,
                    onClick = onAddPdf,
                    contentDesc = "Add PDF"
                )

                Spacer(modifier = Modifier.width(4.dp))

                // Colors
                drawingColors.forEach { argb ->
                    Box(
                        modifier = Modifier
                            .size(22.dp)
                            .padding(2.dp)
                            .clip(CircleShape)
                            .background(Color(argb))
                            .clickable { onSelectColor(argb) }
                            .then(
                                if (selectedColorArgb == argb) {
                                    Modifier.border(2.dp, Color.White, CircleShape)
                                } else Modifier
                            )
                    )
                }

                Spacer(modifier = Modifier.width(4.dp))

                // Stroke Width Chips
                WidthSelectorChip(
                    label = "S",
                    isSelected = strokeWidthFraction < 0.007f,
                    onClick = { onSelectWidth(0.004f) }
                )
                WidthSelectorChip(
                    label = "M",
                    isSelected = strokeWidthFraction in 0.007f..0.015f,
                    onClick = { onSelectWidth(0.009f) }
                )
                WidthSelectorChip(
                    label = "L",
                    isSelected = strokeWidthFraction > 0.015f,
                    onClick = { onSelectWidth(0.020f) }
                )
            }

            // Undo, Redo, Clear Page, Pages, Snapshot, Face-cam, Record
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onUndo, modifier = Modifier.size(30.dp)) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Undo,
                        contentDescription = "Undo",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
                IconButton(onClick = onRedo, modifier = Modifier.size(30.dp)) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Redo,
                        contentDescription = "Redo",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }

                // Clear Menu button (Clears text, strokes, images, or all)
                IconButton(onClick = onOpenClearMenu, modifier = Modifier.size(30.dp)) {
                    Icon(
                        imageVector = Icons.Default.DeleteSweep,
                        contentDescription = "Clear Options",
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Page switcher chips
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .padding(horizontal = 2.dp)
                        .background(Color(0xFF262A38), RoundedCornerShape(12.dp))
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    IconButton(
                        onClick = onPrevSlide,
                        enabled = currentSlideIndex > 0,
                        modifier = Modifier.size(22.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ChevronLeft,
                            contentDescription = "Prev slide",
                            tint = if (currentSlideIndex > 0) Color.White else Color.Gray,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Text(
                        text = "${currentSlideIndex + 1}/$totalSlides",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(
                        onClick = onNextSlide,
                        enabled = currentSlideIndex < totalSlides - 1,
                        modifier = Modifier.size(22.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = "Next slide",
                            tint = if (currentSlideIndex < totalSlides - 1) Color.White else Color.Gray,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                // Snapshot button
                IconButton(onClick = onScreenshot, modifier = Modifier.size(30.dp)) {
                    Icon(
                        imageVector = Icons.Default.Screenshot,
                        contentDescription = "Snapshot",
                        tint = Color.White,
                        modifier = Modifier.size(17.dp)
                    )
                }

                // Face-Cam Toggle
                IconButton(
                    onClick = onToggleFaceCam,
                    modifier = Modifier
                        .size(30.dp)
                        .background(
                            if (faceCamEnabled) MaterialTheme.colorScheme.secondary.copy(alpha = 0.3f) else Color.Transparent,
                            CircleShape
                        )
                ) {
                    Icon(
                        imageVector = Icons.Default.CameraAlt,
                        contentDescription = "Face-Cam",
                        tint = if (faceCamEnabled) MaterialTheme.colorScheme.secondary else Color.White,
                        modifier = Modifier.size(17.dp)
                    )
                }

                Spacer(modifier = Modifier.width(2.dp))

                // Record / Pause / Stop Button
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val isRecording = recorderState is RecorderState.Recording
                    val isPaused = recorderState is RecorderState.Paused

                    Button(
                        onClick = onRecordClick,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = when {
                                isRecording -> Color(0xFFE53935)
                                isPaused -> Color(0xFFFF9800)
                                else -> MaterialTheme.colorScheme.secondary
                            }
                        ),
                        modifier = Modifier
                            .height(32.dp)
                            .testTag("btn_stage_record")
                    ) {
                        Icon(
                            imageVector = when {
                                isRecording -> Icons.Default.Pause
                                isPaused -> Icons.Default.PlayArrow
                                else -> Icons.Default.FiberManualRecord
                            },
                            contentDescription = null,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = when {
                                isRecording -> "Pause"
                                isPaused -> "Resume"
                                else -> "REC"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (isRecording || isPaused) {
                        Spacer(modifier = Modifier.width(3.dp))
                        IconButton(
                            onClick = onStopRecord,
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.15f))
                                .testTag("btn_stage_stop")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Stop,
                                contentDescription = "Stop",
                                tint = Color.White,
                                modifier = Modifier.size(17.dp)
                            )
                        }
                    }
                }

                // Hide toolbar toggle button
                IconButton(
                    onClick = onToggleHideToolbar,
                    modifier = Modifier.size(30.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.VisibilityOff,
                        contentDescription = "Hide Tools",
                        tint = Color.White.copy(alpha = 0.6f),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ToolIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    contentDesc: String
) {
    Box(
        modifier = Modifier
            .size(30.dp)
            .clip(CircleShape)
            .background(if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDesc,
            tint = if (isSelected) Color.White else Color.White.copy(alpha = 0.8f),
            modifier = Modifier.size(16.dp)
        )
    }
}

@Composable
private fun WidthSelectorChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .padding(horizontal = 2.dp)
            .size(20.dp)
            .clip(CircleShape)
            .background(if (isSelected) MaterialTheme.colorScheme.secondary else Color(0xFF2E3242))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
            color = Color.White,
            fontWeight = FontWeight.Bold
        )
    }
}
