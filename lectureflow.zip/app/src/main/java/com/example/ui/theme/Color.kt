package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Indigo Primary
val IndigoPrimaryLight = Color(0xFF283593)
val IndigoOnPrimaryLight = Color(0xFFFFFFFF)
val IndigoContainerLight = Color(0xFFE8EAF6)
val IndigoOnContainerLight = Color(0xFF1A237E)

val IndigoPrimaryDark = Color(0xFF9FA8DA)
val IndigoOnPrimaryDark = Color(0xFF1A237E)
val IndigoContainerDark = Color(0xFF283593)
val IndigoOnContainerDark = Color(0xFFE8EAF6)

// Coral Secondary
val CoralSecondaryLight = Color(0xFFFF5722)
val CoralOnSecondaryLight = Color(0xFFFFFFFF)
val CoralContainerLight = Color(0xFFFFEBE5)
val CoralOnContainerLight = Color(0xFFBF360C)

val CoralSecondaryDark = Color(0xFFFF8A65)
val CoralOnSecondaryDark = Color(0xFF3E1200)
val CoralContainerDark = Color(0xFFD84315)
val CoralOnContainerDark = Color(0xFFFFDBCF)

// Canvas & Neutral Backgrounds
val NeutralBackgroundLight = Color(0xFFF7F8FC)
val NeutralOnBackgroundLight = Color(0xFF191C24)
val NeutralSurfaceLight = Color(0xFFFFFFFF)
val NeutralOnSurfaceLight = Color(0xFF191C24)
val NeutralSurfaceVariantLight = Color(0xFFE2E4EF)
val NeutralOnSurfaceVariantLight = Color(0xFF454752)

val NeutralBackgroundDark = Color(0xFF111319)
val NeutralOnBackgroundDark = Color(0xFFE3E4ED)
val NeutralSurfaceDark = Color(0xFF181B24)
val NeutralOnSurfaceDark = Color(0xFFE3E4ED)
val NeutralSurfaceVariantDark = Color(0xFF262A38)
val NeutralOnSurfaceVariantDark = Color(0xFFC6C7D5)

// Drawing Colors
val DrawColorBlack = Color(0xFF212121)
val DrawColorWhite = Color(0xFFFFFFFF)
val DrawColorIndigo = Color(0xFF3F51B5)
val DrawColorCoral = Color(0xFFFF5722)
val DrawColorEmerald = Color(0xFF2E7D32)
val DrawColorAmber = Color(0xFFF57F17)
val DrawColorCrimson = Color(0xFFD50000)
val DrawColorCyan = Color(0xFF0097A7)
