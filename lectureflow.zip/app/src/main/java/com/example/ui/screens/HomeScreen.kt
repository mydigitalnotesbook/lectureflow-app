package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Web
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.AspectRatio
import com.example.model.Deck
import com.example.model.SlideSourceType
import com.example.viewmodel.MainViewModel
import com.example.viewmodel.Screen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val decks by viewModel.decks.collectAsState()
    val lectures by viewModel.lectures.collectAsState()
    val pdfStatus by viewModel.pdfImportStatus.collectAsState()
    val recorderConfig by viewModel.recorderConfig.collectAsState()

    var showMenu by remember { mutableStateOf(false) }
    var showCreateDialog by remember { mutableStateOf(false) }

    var pendingPdfTitle by remember { mutableStateOf("Imported PDF Lesson") }
    var pendingPdfRatio by remember { mutableStateOf(recorderConfig.defaultRatio) }

    // PDF Picker Launcher with universal GetContent
    val pdfPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            viewModel.importPdfToDeck(
                title = pendingPdfTitle,
                ratio = pendingPdfRatio,
                uri = it
            )
        }
    }

    // Images Picker Launcher
    val imagesPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            viewModel.createNewDeck(
                title = "Photo Deck",
                ratio = recorderConfig.defaultRatio,
                sourceType = SlideSourceType.IMAGE
            )
        }
    }

    Scaffold(
        modifier = modifier.testTag("home_screen"),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Description,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = stringResource(R.string.app_name),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = stringResource(R.string.app_tagline),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showMenu = true },
                        modifier = Modifier.testTag("home_menu_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "Options"
                        )
                    }
                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.nav_settings)) },
                            leadingIcon = { Icon(Icons.Default.Settings, contentDescription = null) },
                            onClick = {
                                showMenu = false
                                viewModel.navigateTo(Screen.Settings)
                            },
                            modifier = Modifier.testTag("menu_settings")
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.nav_about)) },
                            leadingIcon = { Icon(Icons.Default.Info, contentDescription = null) },
                            onClick = {
                                showMenu = false
                                viewModel.navigateTo(Screen.About)
                            },
                            modifier = Modifier.testTag("menu_about")
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showCreateDialog = true },
                containerColor = MaterialTheme.colorScheme.secondary,
                contentColor = MaterialTheme.colorScheme.onSecondary,
                modifier = Modifier.testTag("fab_new_deck")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = stringResource(R.string.action_new_deck)
                )
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // PDF Import Progress Banner
            if (pdfStatus.isImporting) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = stringResource(R.string.pdf_importing_title),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = stringResource(
                                    R.string.pdf_importing_progress,
                                    pdfStatus.current,
                                    pdfStatus.total
                                ),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            val progress = if (pdfStatus.total > 0) {
                                pdfStatus.current.toFloat() / pdfStatus.total
                            } else 0f
                            LinearProgressIndicator(
                                progress = { progress },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }

            // Welcome Hero Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    )
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = stringResource(R.string.home_hero_title),
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = stringResource(R.string.home_hero_subtitle),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.88f)
                        )
                    }
                }
            }

            // Folder 1: Slides Deck Folder
            item {
                val latestDeckDate = decks.maxOfOrNull { it.updatedAt }
                FolderRowCard(
                    icon = Icons.Default.Folder,
                    iconBg = MaterialTheme.colorScheme.primaryContainer,
                    iconTint = MaterialTheme.colorScheme.primary,
                    title = stringResource(R.string.folder_slides_title),
                    description = stringResource(R.string.folder_slides_desc),
                    badgeText = stringResource(R.string.badge_decks_count, decks.size),
                    dateText = latestDeckDate?.let {
                        stringResource(R.string.last_updated, formatDate(it))
                    } ?: "",
                    onClick = {
                        decks.firstOrNull()?.let {
                            viewModel.navigateTo(Screen.SlideList(it.id))
                        } ?: run {
                            showCreateDialog = true
                        }
                    },
                    modifier = Modifier.testTag("folder_slides_row")
                )
            }

            // Folder 2: Lectures Library Folder
            item {
                val latestLectureDate = lectures.maxOfOrNull { it.dateRecorded }
                FolderRowCard(
                    icon = Icons.Default.VideoLibrary,
                    iconBg = MaterialTheme.colorScheme.secondaryContainer,
                    iconTint = MaterialTheme.colorScheme.secondary,
                    title = stringResource(R.string.folder_lectures_title),
                    description = stringResource(R.string.folder_lectures_desc),
                    badgeText = stringResource(R.string.badge_lectures_count, lectures.size),
                    dateText = latestLectureDate?.let {
                        stringResource(R.string.last_updated, formatDate(it))
                    } ?: "",
                    onClick = {
                        viewModel.navigateTo(Screen.Lectures)
                    },
                    modifier = Modifier.testTag("folder_lectures_row")
                )
            }

            // Slide Decks Header & List
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.folder_slides_title),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    TextButton(onClick = { showCreateDialog = true }) {
                        Text("+ " + stringResource(R.string.action_new_deck))
                    }
                }
            }

            items(decks) { deck ->
                DeckListItem(
                    deck = deck,
                    onClick = { viewModel.navigateTo(Screen.SlideList(deck.id)) },
                    onStartStage = { viewModel.navigateTo(Screen.Stage(deck.id, 0)) }
                )
            }
        }
    }

    // Create Deck Dialog (Ratio + Source)
    if (showCreateDialog) {
        CreateDeckDialog(
            defaultRatio = recorderConfig.defaultRatio,
            onDismiss = { showCreateDialog = false },
            onCreate = { title, ratio, source, webUrl ->
                showCreateDialog = false
                when (source) {
                    SlideSourceType.PDF_PAGE -> {
                        pendingPdfTitle = title
                        pendingPdfRatio = ratio
                        pdfPickerLauncher.launch("application/pdf")
                    }
                    SlideSourceType.IMAGE -> {
                        imagesPickerLauncher.launch("image/*")
                    }
                    SlideSourceType.WEB_PAGE -> {
                        viewModel.createNewDeck(title, ratio, source, webUrl)
                    }
                    else -> {
                        viewModel.createNewDeck(title, ratio, source)
                    }
                }
            }
        )
    }
}

@Composable
private fun FolderRowCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconBg: Color,
    iconTint: Color,
    title: String,
    description: String,
    badgeText: String,
    dateText: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(iconBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = badgeText,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (dateText.isNotBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = dateText,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

@Composable
private fun DeckListItem(
    deck: Deck,
    onClick: () -> Unit,
    onStartStage: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("deck_item_${deck.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(
                        if (deck.ratio == AspectRatio.RATIO_16_9)
                            MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.secondaryContainer
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = deck.ratio.label,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = if (deck.ratio == AspectRatio.RATIO_16_9)
                        MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.secondary
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = deck.title,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${deck.slides.size} slides • ${formatDate(deck.updatedAt)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            IconButton(
                onClick = onStartStage,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f))
                    .testTag("start_stage_button_${deck.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Open Stage",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
private fun CreateDeckDialog(
    defaultRatio: AspectRatio,
    onDismiss: () -> Unit,
    onCreate: (title: String, ratio: AspectRatio, source: SlideSourceType, webUrl: String?) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var selectedRatio by remember { mutableStateOf(defaultRatio) }
    var selectedSource by remember { mutableStateOf(SlideSourceType.BLANK_WHITE) }
    var webUrl by remember { mutableStateOf("https://en.wikipedia.org") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.dialog_create_deck_title)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Deck Title") },
                    placeholder = { Text("e.g. Organic Chemistry Lecture 1") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_deck_title")
                )

                Text(
                    text = stringResource(R.string.dialog_choose_ratio),
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(
                        selected = selectedRatio == AspectRatio.RATIO_16_9,
                        onClick = { selectedRatio = AspectRatio.RATIO_16_9 }
                    )
                    Text(
                        text = "16:9 Landscape",
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.clickable { selectedRatio = AspectRatio.RATIO_16_9 }
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    RadioButton(
                        selected = selectedRatio == AspectRatio.RATIO_9_16,
                        onClick = { selectedRatio = AspectRatio.RATIO_9_16 }
                    )
                    Text(
                        text = "9:16 Portrait",
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.clickable { selectedRatio = AspectRatio.RATIO_9_16 }
                    )
                }

                Text(
                    text = stringResource(R.string.dialog_choose_source),
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )

                val sources = listOf(
                    SlideSourceType.BLANK_WHITE to stringResource(R.string.source_blank_white),
                    SlideSourceType.BLANK_DARK to stringResource(R.string.source_blank_dark),
                    SlideSourceType.IMAGE to stringResource(R.string.source_images),
                    SlideSourceType.PDF_PAGE to stringResource(R.string.source_pdf),
                    SlideSourceType.WEB_PAGE to stringResource(R.string.source_web)
                )

                sources.forEach { (src, label) ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedSource = src }
                            .padding(vertical = 2.dp)
                    ) {
                        RadioButton(
                            selected = selectedSource == src,
                            onClick = { selectedSource = src }
                        )
                        Text(
                            text = label,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }

                if (selectedSource == SlideSourceType.WEB_PAGE) {
                    OutlinedTextField(
                        value = webUrl,
                        onValueChange = { webUrl = it },
                        label = { Text("Web URL") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val finalTitle = title.trim().ifEmpty { "Lecture Deck" }
                    onCreate(finalTitle, selectedRatio, selectedSource, webUrl)
                },
                modifier = Modifier.testTag("btn_confirm_create_deck")
            ) {
                Text(stringResource(R.string.btn_create))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.btn_cancel))
            }
        }
    )
}

private fun formatDate(ms: Long): String {
    return SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(ms))
}
