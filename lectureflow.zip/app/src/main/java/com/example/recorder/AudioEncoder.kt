package com.example.recorder

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.util.Log
import java.nio.ByteBuffer

class AudioEncoder(
    private val audioSource: Int,
    private val sampleRate: Int = 44100,
    private val bitrateBps: Int = 128_000,
    private val muxerHub: MuxerHub
) {
    private val TAG = "AudioEncoder"

    private var audioRecord: AudioRecord? = null
    private var codec: MediaCodec? = null
    private var audioTrackIndex = -1

    @Volatile
    private var isRunning = false
    @Volatile
    private var isPaused = false

    private var recordThread: Thread? = null
    private var startNanoTime = 0L
    @Volatile
    private var totalPausedNanoTime = 0L
    private var pauseStartNanoTime = 0L

    @SuppressLint("MissingPermission")
    fun start(startTimeNanos: Long) {
        startNanoTime = startTimeNanos

        val channelConfig = AudioFormat.CHANNEL_IN_MONO
        val audioFormat = AudioFormat.ENCODING_PCM_16BIT
        val minBufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)
        val bufferSize = (minBufferSize * 2).coerceAtLeast(4096)

        try {
            audioRecord = AudioRecord(audioSource, sampleRate, channelConfig, audioFormat, bufferSize)
            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                Log.e(TAG, "AudioRecord failed to initialize")
                return
            }

            val format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, 1).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, bitrateBps)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, bufferSize)
            }

            val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            encoder.start()
            codec = encoder

            audioRecord?.startRecording()
            isRunning = true
            isPaused = false

            recordThread = Thread({
                runAudioLoop(bufferSize)
            }, "AudioRecordThread").apply {
                priority = Thread.MAX_PRIORITY
                start()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start AudioEncoder", e)
        }
    }

    fun pause() {
        if (!isPaused) {
            isPaused = true
            pauseStartNanoTime = System.nanoTime()
            Log.d(TAG, "Audio encoder paused")
        }
    }

    fun resume() {
        if (isPaused) {
            totalPausedNanoTime += (System.nanoTime() - pauseStartNanoTime)
            isPaused = false
            Log.d(TAG, "Audio encoder resumed")
        }
    }

    private fun runAudioLoop(bufferSize: Int) {
        val pcmBuffer = ByteArray(bufferSize)
        val bufferInfo = MediaCodec.BufferInfo()

        while (isRunning) {
            val record = audioRecord ?: break
            val bytesRead = record.read(pcmBuffer, 0, pcmBuffer.size)

            if (bytesRead > 0 && !isPaused) {
                feedCodec(pcmBuffer, bytesRead)
                drainOutput(bufferInfo, endOfStream = false)
            } else if (isPaused) {
                // Sleep briefly while paused so loop doesn't spin
                try {
                    Thread.sleep(20)
                } catch (ignored: InterruptedException) {
                    break
                }
            }
        }

        drainOutput(bufferInfo, endOfStream = true)
    }

    private fun feedCodec(data: ByteArray, length: Int) {
        val encoder = codec ?: return
        val inputBufferIndex = encoder.dequeueInputBuffer(10_000)
        if (inputBufferIndex >= 0) {
            val inputBuffer: ByteBuffer? = encoder.getInputBuffer(inputBufferIndex)
            inputBuffer?.clear()
            inputBuffer?.put(data, 0, length)

            val ptsUs = ((System.nanoTime() - startNanoTime - totalPausedNanoTime) / 1000L).coerceAtLeast(0L)
            encoder.queueInputBuffer(inputBufferIndex, 0, length, ptsUs, 0)
        }
    }

    private fun drainOutput(bufferInfo: MediaCodec.BufferInfo, endOfStream: Boolean) {
        val encoder = codec ?: return

        while (true) {
            val outputBufferIndex = encoder.dequeueOutputBuffer(bufferInfo, 0)
            if (outputBufferIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!endOfStream) break
            } else if (outputBufferIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                val newFormat = encoder.outputFormat
                audioTrackIndex = muxerHub.addTrack(newFormat, isVideo = false)
                Log.d(TAG, "Audio encoder format changed: $newFormat, trackIndex: $audioTrackIndex")
            } else if (outputBufferIndex >= 0) {
                val outputBuffer: ByteBuffer? = encoder.getOutputBuffer(outputBufferIndex)
                if (outputBuffer != null) {
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                        bufferInfo.size = 0
                    }

                    if (bufferInfo.size != 0) {
                        val ptsUs = ((System.nanoTime() - startNanoTime - totalPausedNanoTime) / 1000L).coerceAtLeast(0L)
                        bufferInfo.presentationTimeUs = ptsUs
                        muxerHub.writeSampleData(audioTrackIndex, outputBuffer, bufferInfo, isVideo = false)
                    }

                    encoder.releaseOutputBuffer(outputBufferIndex, false)
                }

                if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                    break
                }
            }
        }
    }

    fun stop() {
        isRunning = false
        try {
            recordThread?.join(1000)
        } catch (e: Exception) {
            Log.w(TAG, "Interrupted waiting for audio thread", e)
        }
        recordThread = null

        try {
            audioRecord?.stop()
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping AudioRecord", e)
        }
        try {
            audioRecord?.release()
        } catch (e: Exception) {
            Log.w(TAG, "Error releasing AudioRecord", e)
        }
        audioRecord = null

        try {
            codec?.stop()
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping audio codec", e)
        }
        try {
            codec?.release()
        } catch (e: Exception) {
            Log.w(TAG, "Error releasing audio codec", e)
        }
        codec = null
    }
}
