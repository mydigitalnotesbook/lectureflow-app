package com.example.recorder

import android.graphics.Canvas
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.os.Build
import android.util.Log
import android.view.Surface
import java.nio.ByteBuffer

class VideoEncoder(
    val width: Int,
    val height: Int,
    val fps: Int,
    val bitrateBps: Int,
    val mimeType: String,
    private val muxerHub: MuxerHub,
    private val onRenderFrame: (canvas: Canvas, width: Int, height: Int) -> Unit
) {
    private val TAG = "VideoEncoder"

    private var codec: MediaCodec? = null
    private var inputSurface: Surface? = null
    private var videoTrackIndex = -1

    @Volatile
    private var isRunning = false
    @Volatile
    private var isPaused = false

    private var renderThread: Thread? = null
    private var startNanoTime = 0L
    @Volatile
    private var totalPausedNanoTime = 0L
    private var pauseStartNanoTime = 0L

    fun start(startTimeNanos: Long) {
        startNanoTime = startTimeNanos
        val format = MediaFormat.createVideoFormat(mimeType, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrateBps)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }

        val encoder = MediaCodec.createEncoderByType(mimeType)
        encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        inputSurface = encoder.createInputSurface()
        encoder.start()
        codec = encoder

        isRunning = true
        isPaused = false

        renderThread = Thread({
            runRenderLoop()
        }, "VideoRenderThread").apply {
            priority = Thread.MAX_PRIORITY
            start()
        }
    }

    fun pause() {
        if (!isPaused) {
            isPaused = true
            pauseStartNanoTime = System.nanoTime()
            Log.d(TAG, "Video encoder paused")
        }
    }

    fun resume() {
        if (isPaused) {
            totalPausedNanoTime += (System.nanoTime() - pauseStartNanoTime)
            isPaused = false
            Log.d(TAG, "Video encoder resumed")
        }
    }

    private fun runRenderLoop() {
        val frameIntervalMs = (1000L / fps).coerceAtLeast(16L)
        val bufferInfo = MediaCodec.BufferInfo()

        while (isRunning) {
            val loopStartMs = System.currentTimeMillis()

            if (!isPaused) {
                renderAndDrainFrame(bufferInfo)
            }

            val elapsedMs = System.currentTimeMillis() - loopStartMs
            val sleepMs = frameIntervalMs - elapsedMs
            if (sleepMs > 0) {
                try {
                    Thread.sleep(sleepMs)
                } catch (ignored: InterruptedException) {
                    break
                }
            }
        }

        // Drain any remaining frames
        drainOutput(bufferInfo, endOfStream = true)
    }

    private fun renderAndDrainFrame(bufferInfo: MediaCodec.BufferInfo) {
        val surface = inputSurface ?: return
        val encoder = codec ?: return

        try {
            val canvas: Canvas = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                try {
                    surface.lockHardwareCanvas()
                } catch (e: Exception) {
                    surface.lockCanvas(null)
                }
            } else {
                surface.lockCanvas(null)
            }

            try {
                onRenderFrame(canvas, width, height)
            } finally {
                surface.unlockCanvasAndPost(canvas)
            }

            drainOutput(bufferInfo, endOfStream = false)
        } catch (e: Exception) {
            Log.e(TAG, "Error during canvas render or post", e)
        }
    }

    private fun drainOutput(bufferInfo: MediaCodec.BufferInfo, endOfStream: Boolean) {
        val encoder = codec ?: return
        if (endOfStream) {
            try {
                encoder.signalEndOfInputStream()
            } catch (e: Exception) {
                Log.w(TAG, "signalEndOfInputStream failed", e)
            }
        }

        while (true) {
            val outputBufferIndex = encoder.dequeueOutputBuffer(bufferInfo, 0)
            if (outputBufferIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!endOfStream) break
            } else if (outputBufferIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                val newFormat = encoder.outputFormat
                videoTrackIndex = muxerHub.addTrack(newFormat, isVideo = true)
                Log.d(TAG, "Video encoder output format changed: $newFormat, trackIndex: $videoTrackIndex")
            } else if (outputBufferIndex >= 0) {
                val outputBuffer: ByteBuffer? = encoder.getOutputBuffer(outputBufferIndex)
                if (outputBuffer != null) {
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                        bufferInfo.size = 0
                    }

                    if (bufferInfo.size != 0) {
                        // Calculate presentation timestamp based on master clock minus paused time
                        val ptsUs = ((System.nanoTime() - startNanoTime - totalPausedNanoTime) / 1000L).coerceAtLeast(0L)
                        bufferInfo.presentationTimeUs = ptsUs
                        muxerHub.writeSampleData(videoTrackIndex, outputBuffer, bufferInfo, isVideo = true)
                    }

                    encoder.releaseOutputBuffer(outputBufferIndex, false)
                }

                if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                    break
                }
            }
        }
    }

    fun stop() {
        isRunning = false
        try {
            renderThread?.join(1000)
        } catch (e: Exception) {
            Log.w(TAG, "Interrupted waiting for render thread", e)
        }
        renderThread = null

        try {
            codec?.stop()
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping video codec", e)
        }
        try {
            codec?.release()
        } catch (e: Exception) {
            Log.w(TAG, "Error releasing video codec", e)
        }
        codec = null

        inputSurface?.release()
        inputSurface = null
    }
}
