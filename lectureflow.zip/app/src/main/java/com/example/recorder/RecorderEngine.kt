package com.example.recorder

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import android.util.Log
import com.example.model.AspectRatio
import com.example.settings.FpsOption
import com.example.settings.QualityOption
import com.example.settings.RecorderConfig
import com.example.settings.VideoBitrateOption
import com.example.settings.VideoCodecOption
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RecorderEngine(
    private val context: Context,
    private val onRenderFrame: (canvas: Canvas, width: Int, height: Int) -> Unit,
    private val onLowStorage: () -> Unit,
    private val onFallbackApplied: (String) -> Unit
) {
    private val TAG = "RecorderEngine"

    private var muxerHub: MuxerHub? = null
    private var videoEncoder: VideoEncoder? = null
    private var audioEncoder: AudioEncoder? = null
    private var tempOutputFile: File? = null

    private var isRecording = false
    private var isPaused = false
    private var startNanoTime = 0L
    private var pauseStartTime = 0L
    private var totalPausedDurationMs = 0L

    private var storageMonitorJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default)

    data class RecordingResult(
        val uri: Uri,
        val filePath: String,
        val durationMs: Long,
        val fileSizeBytes: Long,
        val thumbnailPath: String?
    )

    fun start(config: RecorderConfig, ratio: AspectRatio): Boolean {
        // Try requested config first, with automatic hardware fallback chain if needed
        val configsToTry = generateFallbackConfigs(config)

        for (candidate in configsToTry) {
            val success = tryStartWithConfig(candidate, ratio)
            if (success) {
                if (candidate != config) {
                    onFallbackApplied("Settings automatically adjusted for hardware compatibility (${candidate.videoCodec.name}, ${candidate.quality.shortSide}p, ${candidate.fps.fps}fps).")
                }
                return true
            }
        }

        return false
    }

    private fun generateFallbackConfigs(initial: RecorderConfig): List<RecorderConfig> {
        val list = mutableListOf(initial)

        // 1. If HEVC, try H264
        if (initial.videoCodec == VideoCodecOption.HEVC) {
            list.add(initial.copy(videoCodec = VideoCodecOption.H264))
        }

        // 2. If 60fps, try 30fps
        if (initial.fps == FpsOption.FPS_60) {
            list.add(initial.copy(videoCodec = VideoCodecOption.H264, fps = FpsOption.FPS_30))
        }

        // 3. If 1080p, try 720p
        if (initial.quality == QualityOption.P1080) {
            list.add(initial.copy(
                videoCodec = VideoCodecOption.H264,
                fps = FpsOption.FPS_30,
                quality = QualityOption.P720,
                videoBitrate = VideoBitrateOption.MBPS_4
            ))
        }

        return list.distinct()
    }

    private fun tryStartWithConfig(config: RecorderConfig, ratio: AspectRatio): Boolean {
        cleanup()

        try {
            val (width, height) = ratio.calculateResolution(config.quality.shortSide)
            val tempDir = File(context.cacheDir, "recorders").apply { mkdirs() }
            tempOutputFile = File(tempDir, "temp_rec_${System.currentTimeMillis()}.mp4")

            val hub = MuxerHub(tempOutputFile!!.absolutePath, expectAudio = true)
            muxerHub = hub

            val vEncoder = VideoEncoder(
                width = width,
                height = height,
                fps = config.fps.fps,
                bitrateBps = config.videoBitrate.bps,
                mimeType = config.videoCodec.mimeType,
                muxerHub = hub,
                onRenderFrame = onRenderFrame
            )

            val aEncoder = AudioEncoder(
                audioSource = config.audioSource.sourceValue,
                sampleRate = 44100,
                bitrateBps = config.audioBitrate.bps,
                muxerHub = hub
            )

            startNanoTime = System.nanoTime()
            vEncoder.start(startNanoTime)
            aEncoder.start(startNanoTime)

            videoEncoder = vEncoder
            audioEncoder = aEncoder
            isRecording = true
            isPaused = false
            totalPausedDurationMs = 0L

            startStorageMonitor()
            return true
        } catch (e: Exception) {
            Log.w(TAG, "Failed to start with config: ${config.videoCodec}, ${config.quality}", e)
            cleanup()
            return false
        }
    }

    private fun startStorageMonitor() {
        storageMonitorJob?.cancel()
        storageMonitorJob = scope.launch {
            while (isActive && isRecording) {
                delay(3000)
                try {
                    val stat = StatFs(context.filesDir.path)
                    val availableBytes = stat.availableBytes
                    if (availableBytes < 50L * 1024 * 1024) { // Under 50MB
                        Log.w(TAG, "Low storage detected (<50MB). Triggering safe stop.")
                        withContext(Dispatchers.Main) {
                            onLowStorage()
                        }
                        break
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Storage check error", e)
                }
            }
        }
    }

    fun pause() {
        if (isRecording && !isPaused) {
            isPaused = true
            pauseStartTime = System.currentTimeMillis()
            videoEncoder?.pause()
            audioEncoder?.pause()
        }
    }

    fun resume() {
        if (isRecording && isPaused) {
            totalPausedDurationMs += (System.currentTimeMillis() - pauseStartTime)
            isPaused = false
            videoEncoder?.resume()
            audioEncoder?.resume()
        }
    }

    fun getCurrentDurationMs(): Long {
        if (!isRecording) return 0L
        val now = System.currentTimeMillis()
        val elapsed = (now - (startNanoTime / 1_000_000L)) - totalPausedDurationMs
        return if (isPaused) {
            (pauseStartTime - (startNanoTime / 1_000_000L)) - totalPausedDurationMs
        } else {
            elapsed.coerceAtLeast(0L)
        }
    }

    suspend fun stopAndSave(lectureTitle: String? = null): RecordingResult? = withContext(Dispatchers.IO) {
        if (!isRecording) return@withContext null
        isRecording = false
        isPaused = false
        storageMonitorJob?.cancel()

        val finalDurationMs = getCurrentDurationMs()

        // Stop encoders and muxer
        videoEncoder?.stop()
        audioEncoder?.stop()
        muxerHub?.stopAndRelease()

        val tempFile = tempOutputFile
        if (tempFile == null || !tempFile.exists() || tempFile.length() == 0L) {
            Log.e(TAG, "Output file does not exist or is empty")
            cleanup()
            return@withContext null
        }

        // Save to MediaStore (Movies/My Digital Notes Book)
        val title = lectureTitle?.takeIf { it.isNotBlank() }
            ?: "Lecture_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}"
        val displayName = "$title.mp4"

        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.TITLE, title)
            put(MediaStore.Video.Media.DATE_ADDED, System.currentTimeMillis() / 1000)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/My Digital Notes Book")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
        }

        val resolver = context.contentResolver
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }

        val itemUri = resolver.insert(collection, values)
        var savedPath = tempFile.absolutePath

        if (itemUri != null) {
            try {
                resolver.openOutputStream(itemUri)?.use { out ->
                    FileInputStream(tempFile).use { input ->
                        input.copyTo(out)
                    }
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    values.clear()
                    values.put(MediaStore.Video.Media.IS_PENDING, 0)
                    resolver.update(itemUri, values, null, null)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to copy video to MediaStore", e)
            }
        }

        // Generate thumbnail
        val thumbPath = extractThumbnail(tempFile, title)
        val fileSize = tempFile.length()

        cleanup()

        RecordingResult(
            uri = itemUri ?: Uri.fromFile(tempFile),
            filePath = savedPath,
            durationMs = finalDurationMs,
            fileSizeBytes = fileSize,
            thumbnailPath = thumbPath
        )
    }

    private fun extractThumbnail(videoFile: File, title: String): String? {
        return try {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(videoFile.absolutePath)
            val frame = retriever.getFrameAtTime(500_000) // 0.5s in
            retriever.release()

            if (frame != null) {
                val thumbFile = File(context.filesDir, "thumbs/thumb_${System.currentTimeMillis()}.jpg").apply {
                    parentFile?.mkdirs()
                }
                FileOutputStream(thumbFile).use { fos ->
                    frame.compress(Bitmap.CompressFormat.JPEG, 85, fos)
                }
                frame.recycle()
                thumbFile.absolutePath
            } else null
        } catch (e: Exception) {
            Log.w(TAG, "Failed to extract thumbnail", e)
            null
        }
    }

    fun cleanup() {
        videoEncoder?.stop()
        audioEncoder?.stop()
        muxerHub?.stopAndRelease()
        videoEncoder = null
        audioEncoder = null
        muxerHub = null
        isRecording = false
        isPaused = false
    }
}
