package com.example.recorder

import android.media.MediaCodec
import android.media.MediaFormat
import android.media.MediaMuxer
import android.util.Log
import java.nio.ByteBuffer

/**
 * Thread-safe hub wrapping MediaMuxer.
 * Coordinates track registration and ensures muxer only starts when both video
 * and audio tracks exist (or video only if audio is disabled).
 */
class MuxerHub(
    outputFilePath: String,
    private val expectAudio: Boolean = true
) {
    private val TAG = "MuxerHub"

    private var muxer: MediaMuxer? = MediaMuxer(outputFilePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
    private var videoTrackIndex = -1
    private var audioTrackIndex = -1
    private var isStarted = false

    private var lastVideoPtsUs = -1L
    private var lastAudioPtsUs = -1L

    private val lock = Any()

    @Synchronized
    fun addTrack(format: MediaFormat, isVideo: Boolean): Int {
        val m = muxer ?: return -1
        val index = m.addTrack(format)
        if (isVideo) {
            videoTrackIndex = index
            Log.d(TAG, "Added video track index: $index")
        } else {
            audioTrackIndex = index
            Log.d(TAG, "Added audio track index: $index")
        }

        checkAndStartMuxer()
        return index
    }

    private fun checkAndStartMuxer() {
        val m = muxer ?: return
        if (isStarted) return

        val videoReady = videoTrackIndex >= 0
        val audioReady = if (expectAudio) audioTrackIndex >= 0 else true

        if (videoReady && audioReady) {
            try {
                m.start()
                isStarted = true
                Log.d(TAG, "MediaMuxer started successfully!")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to start MediaMuxer", e)
            }
        }
    }

    fun writeSampleData(
        trackIndex: Int,
        byteBuffer: ByteBuffer,
        bufferInfo: MediaCodec.BufferInfo,
        isVideo: Boolean
    ) {
        synchronized(lock) {
            val m = muxer ?: return
            if (!isStarted || trackIndex < 0) return

            // Ensure strictly monotonically increasing PTS
            val lastPts = if (isVideo) lastVideoPtsUs else lastAudioPtsUs
            if (bufferInfo.presentationTimeUs <= lastPts) {
                bufferInfo.presentationTimeUs = lastPts + 1000L // increment by 1ms
            }

            if (isVideo) {
                lastVideoPtsUs = bufferInfo.presentationTimeUs
            } else {
                lastAudioPtsUs = bufferInfo.presentationTimeUs
            }

            try {
                m.writeSampleData(trackIndex, byteBuffer, bufferInfo)
            } catch (e: Exception) {
                Log.e(TAG, "Error writing sample data to muxer", e)
            }
        }
    }

    @Synchronized
    fun stopAndRelease() {
        synchronized(lock) {
            try {
                if (isStarted) {
                    muxer?.stop()
                    Log.d(TAG, "MediaMuxer stopped")
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error stopping MediaMuxer", e)
            } finally {
                try {
                    muxer?.release()
                } catch (e: Exception) {
                    Log.w(TAG, "Error releasing MediaMuxer", e)
                }
                muxer = null
                isStarted = false
            }
        }
    }

    val isReady: Boolean get() = isStarted
}
