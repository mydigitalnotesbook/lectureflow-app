package com.example.recorder

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.os.Build
import com.example.model.AspectRatio
import com.example.settings.RecorderConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale

sealed interface RecorderState {
    data object Idle : RecorderState
    data class Countdown(val secondsLeft: Int) : RecorderState
    data class Recording(val durationMs: Long, val formattedTime: String) : RecorderState
    data class Paused(val durationMs: Long, val formattedTime: String, val reason: String? = null) : RecorderState
    data object Saving : RecorderState
}

class RecorderController(
    private val context: Context,
    private val scope: CoroutineScope
) : RecordingService.Companion.ServiceListener {

    private val _state = MutableStateFlow<RecorderState>(RecorderState.Idle)
    val state: StateFlow<RecorderState> = _state.asStateFlow()

    private val _events = MutableSharedFlow<RecorderEvent>()
    val events: SharedFlow<RecorderEvent> = _events.asSharedFlow()

    sealed interface RecorderEvent {
        data class Saved(val result: RecorderEngine.RecordingResult) : RecorderEvent
        data class Error(val message: String) : RecorderEvent
        data class LowStorage(val message: String) : RecorderEvent
        data class FallbackNotice(val message: String) : RecorderEvent
    }

    private var engine: RecorderEngine? = null
    private var tickerJob: Job? = null
    private var countdownJob: Job? = null

    init {
        RecordingService.serviceListener = this
    }

    fun startCountdownAndRecord(
        config: RecorderConfig,
        ratio: AspectRatio,
        onRenderFrame: (canvas: Canvas, width: Int, height: Int) -> Unit
    ) {
        if (_state.value !is RecorderState.Idle) return

        countdownJob?.cancel()
        countdownJob = scope.launch {
            for (sec in 3 downTo 1) {
                _state.value = RecorderState.Countdown(sec)
                delay(1000)
            }
            executeStartRecording(config, ratio, onRenderFrame)
        }
    }

    fun cancelCountdown() {
        countdownJob?.cancel()
        countdownJob = null
        _state.value = RecorderState.Idle
    }

    private fun executeStartRecording(
        config: RecorderConfig,
        ratio: AspectRatio,
        onRenderFrame: (canvas: Canvas, width: Int, height: Int) -> Unit
    ) {
        val newEngine = RecorderEngine(
            context = context,
            onRenderFrame = onRenderFrame,
            onLowStorage = {
                scope.launch {
                    _events.emit(RecorderEvent.LowStorage("Low storage space. Stopping recording safely."))
                    stopRecording()
                }
            },
            onFallbackApplied = { notice ->
                scope.launch {
                    _events.emit(RecorderEvent.FallbackNotice(notice))
                }
            }
        )

        val success = newEngine.start(config, ratio)
        if (!success) {
            _state.value = RecorderState.Idle
            scope.launch {
                _events.emit(RecorderEvent.Error("Unable to initialize video hardware encoder. Please check Recorder Settings."))
            }
            return
        }

        engine = newEngine
        _state.value = RecorderState.Recording(0L, "00:00:00")

        // Start foreground service
        startRecordingService()

        // Start timer ticker
        startTimerTicker()
    }

    private fun startRecordingService() {
        val intent = Intent(context, RecordingService::class.java).apply {
            action = RecordingService.ACTION_START
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
    }

    private fun startTimerTicker() {
        tickerJob?.cancel()
        tickerJob = scope.launch {
            while (isActive) {
                delay(500)
                val eng = engine ?: break
                val durationMs = eng.getCurrentDurationMs()
                val formatted = formatDuration(durationMs)

                val currentState = _state.value
                if (currentState is RecorderState.Recording) {
                    _state.value = RecorderState.Recording(durationMs, formatted)
                    updateServiceTimer(formatted, isPaused = false)
                } else if (currentState is RecorderState.Paused) {
                    updateServiceTimer(formatted, isPaused = true)
                }
            }
        }
    }

    private fun updateServiceTimer(timerText: String, isPaused: Boolean) {
        val intent = Intent(context, RecordingService::class.java).apply {
            action = RecordingService.ACTION_UPDATE_TIMER
            putExtra(RecordingService.EXTRA_TIMER_TEXT, timerText)
        }
        context.startService(intent)
    }

    fun pauseRecording(reason: String? = null) {
        val current = _state.value
        if (current is RecorderState.Recording) {
            engine?.pause()
            _state.value = RecorderState.Paused(current.durationMs, current.formattedTime, reason)
        }
    }

    fun resumeRecording() {
        val current = _state.value
        if (current is RecorderState.Paused) {
            engine?.resume()
            _state.value = RecorderState.Recording(current.durationMs, current.formattedTime)
        }
    }

    fun stopRecording(lectureTitle: String? = null) {
        val eng = engine ?: return
        tickerJob?.cancel()
        countdownJob?.cancel()

        _state.value = RecorderState.Saving

        scope.launch {
            val result = eng.stopAndSave(lectureTitle)
            stopRecordingService()
            engine = null
            _state.value = RecorderState.Idle

            if (result != null) {
                _events.emit(RecorderEvent.Saved(result))
            } else {
                _events.emit(RecorderEvent.Error("Recording failed or was empty."))
            }
        }
    }

    fun discardRecording() {
        tickerJob?.cancel()
        countdownJob?.cancel()
        engine?.cleanup()
        engine = null
        stopRecordingService()
        _state.value = RecorderState.Idle
    }

    private fun stopRecordingService() {
        val intent = Intent(context, RecordingService::class.java).apply {
            action = RecordingService.ACTION_STOP
        }
        context.startService(intent)
    }

    // Callbacks from Service Notification & Telephony
    override fun onServicePauseRequested() {
        pauseRecording()
    }

    override fun onServiceResumeRequested() {
        resumeRecording()
    }

    override fun onServiceStopRequested() {
        stopRecording()
    }

    override fun onServiceAutoPauseCall() {
        pauseRecording(reason = "Incoming Phone Call")
    }

    private fun formatDuration(ms: Long): String {
        val totalSec = ms / 1000
        val sec = totalSec % 60
        val min = (totalSec / 60) % 60
        val hr = totalSec / 3600
        return String.format(Locale.US, "%02d:%02d:%02d", hr, min, sec)
    }
}
