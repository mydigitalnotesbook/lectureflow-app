package com.example.recorder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R

class RecordingService : Service() {

    private val binder = LocalBinder()
    private var isRecording = false
    private var isPaused = false
    private var telephonyManager: TelephonyManager? = null
    private var telephonyCallback: Any? = null

    inner class LocalBinder : Binder() {
        fun getService(): RecordingService = this@RecordingService
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        registerPhoneStateListener()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                isRecording = true
                isPaused = false
                startForegroundWithNotification("00:00:00", isPaused = false)
            }
            ACTION_PAUSE -> {
                isPaused = true
                serviceListener?.onServicePauseRequested()
                updateNotification("Paused", isPaused = true)
            }
            ACTION_RESUME -> {
                isPaused = false
                serviceListener?.onServiceResumeRequested()
                updateNotification("Recording", isPaused = false)
            }
            ACTION_STOP -> {
                isRecording = false
                serviceListener?.onServiceStopRequested()
                stopForeground(true)
                stopSelf()
            }
            ACTION_UPDATE_TIMER -> {
                val timerText = intent.getStringExtra(EXTRA_TIMER_TEXT) ?: "00:00:00"
                if (isRecording) {
                    updateNotification(timerText, isPaused)
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun startForegroundWithNotification(timerText: String, isPaused: Boolean) {
        val notification = buildNotification(timerText, isPaused)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            startForeground(NOTIFICATION_ID, notification, type)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun updateNotification(timerText: String, isPaused: Boolean) {
        updateTimerDisplay(timerText, isPaused)
    }

    fun updateTimerDisplay(timerText: String, paused: Boolean) {
        this.isPaused = paused
        val notification = buildNotification(timerText, paused)
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, notification)
    }

    private fun buildNotification(timerText: String, paused: Boolean): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val pauseResumeIntent = Intent(this, RecordingService::class.java).apply {
            action = if (paused) ACTION_RESUME else ACTION_PAUSE
        }
        val pauseResumePendingIntent = PendingIntent.getService(
            this, 1, pauseResumeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, RecordingService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 2, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = if (paused) {
            getString(R.string.notification_paused_title)
        } else {
            getString(R.string.notification_recording_title)
        }

        val pauseResumeTitle = if (paused) {
            getString(R.string.notification_action_resume)
        } else {
            getString(R.string.notification_action_pause)
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(getString(R.string.notification_recording_text, timerText))
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(openAppPendingIntent)
            .setOngoing(true)
            .setSilent(true)
            .addAction(
                android.R.drawable.ic_media_pause,
                pauseResumeTitle,
                pauseResumePendingIntent
            )
            .addAction(
                android.R.drawable.ic_menu_save,
                getString(R.string.notification_action_stop),
                stopPendingIntent
            )
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_desc)
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun registerPhoneStateListener() {
        try {
            telephonyManager = getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val callback = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                    override fun onCallStateChanged(state: Int) {
                        handleCallState(state)
                    }
                }
                telephonyCallback = callback
                telephonyManager?.registerTelephonyCallback(mainExecutor, callback)
            } else {
                @Suppress("DEPRECATION")
                val listener = object : PhoneStateListener() {
                    @Deprecated("Deprecated in Java")
                    override fun onCallStateChanged(state: Int, phoneNumber: String?) {
                        handleCallState(state)
                    }
                }
                @Suppress("DEPRECATION")
                telephonyManager?.listen(listener, PhoneStateListener.LISTEN_CALL_STATE)
            }
        } catch (ignored: Exception) {
            // Permission or telephony unavailable
        }
    }

    private fun handleCallState(state: Int) {
        if (state == TelephonyManager.CALL_STATE_RINGING || state == TelephonyManager.CALL_STATE_OFFHOOK) {
            if (isRecording && !isPaused) {
                isPaused = true
                serviceListener?.onServiceAutoPauseCall()
                updateNotification("Paused (Incoming Call)", isPaused = true)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (telephonyCallback as? TelephonyCallback)?.let {
                telephonyManager?.unregisterTelephonyCallback(it)
            }
        }
    }

    companion object {
        const val CHANNEL_ID = "lecture_recording_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START = "com.example.recorder.ACTION_START"
        const val ACTION_PAUSE = "com.example.recorder.ACTION_PAUSE"
        const val ACTION_RESUME = "com.example.recorder.ACTION_RESUME"
        const val ACTION_STOP = "com.example.recorder.ACTION_STOP"
        const val ACTION_UPDATE_TIMER = "com.example.recorder.ACTION_UPDATE_TIMER"
        const val EXTRA_TIMER_TEXT = "extra_timer_text"

        interface ServiceListener {
            fun onServicePauseRequested()
            fun onServiceResumeRequested()
            fun onServiceStopRequested()
            fun onServiceAutoPauseCall()
        }

        var serviceListener: ServiceListener? = null
    }
}
