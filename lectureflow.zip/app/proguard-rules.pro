# R8 Proguard rules for My Digital Notes Book

# Keep MediaCodec and MediaMuxer classes and callback interfaces
-keepclassmembers class * implements android.media.MediaCodec$Callback {
    public *;
}

# Keep CameraX internals
-keep class androidx.camera.** { *; }
-dontwarn androidx.camera.**

# Keep Media3 ExoPlayer classes
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**

# Keep DataStore and Kotlin Serialization / Models
-keepclassmembers class * implements java.io.Serializable {
    static final long serialVersionUID;
    private static final java.io.ObjectStreamField[] serialPersistentFields;
    private void writeObject(java.io.ObjectOutputStream);
    private void readObject(java.io.ObjectInputStream);
    java.lang.Object writeReplace();
    java.lang.Object readResolve();
}

# Preserve Line Numbers for Crash Logs
-keepattributes SourceFile,LineNumberTable
